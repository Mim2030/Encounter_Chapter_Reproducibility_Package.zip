# Introduction

Urban analysis has historically privileged movement. Whether the unit is a pedestrian count, a flow on a road segment, or an origin–destination matrix derived from mobile phone records, people are characterized by where they go and the city by the pattern of their displacement (Batty, 2024; Pappalardo et al., 2023). This abstraction serves many planning questions but is poorly matched to those that animate urban design. Designers concerned with the social performance of a plaza or the relationship between street furniture and lingering are not asking how many people pass through; they are asking what happens when people meet. The observational tradition that addressed this question was for decades manual, and recent computational re-analyses of its archival footage show how much a flow count can hide: between the late 1970s and the late 2000s walking speeds in several US public spaces rose by about 15%, lingering halved, and group encounters became less frequent, while the number of people crossing the spaces changed far less (Salazar-Miranda et al., 2025).

Inexpensive cameras, Wi-Fi and Bluetooth Low Energy (BLE) infrastructure and capable computer-vision models now produce continuous behavioural data at fine resolution (Liu, 2025; Piadyk et al., 2023). The gap lies in the analytical unit applied to these data, and three related problems should be distinguished. *Encounter detection* asks when and where two people are co-present. *Social-group recognition* asks who is together; it is well developed in computer vision and robotics, where trajectory-based and multimodal methods detect walking groups and conversational clusters (Ehsanpour et al., 2022; Jahangard et al., 2023). *Behavioural encounter classification* asks what form a co-presence takes, such as passing, walking together or stopping to meet, and how often each form occurs in a designed space. Recent urban video studies have begun to address it (Chen et al., 2025; Niu et al., 2022; van Ameijde et al., 2025), but they rarely state their decision boundaries, calibrate their thresholds or test transfer to new sites. This chapter addresses that third problem, building on the first two.

This chapter makes four contributions to encounter-based urban analytics. First, it proposes an operational framework that represents pedestrian co-presence as a spatiotemporal event, with a six-class encounter taxonomy whose decision boundaries and ambiguity-handling rules are explicit (Figure 1 summarizes the pipeline). Second, it develops a ground-truth-driven protocol for calibrating spatial and temporal detection thresholds, so that their transferability across environments and sensing conditions can be assessed. Third, it compares rule-based, supervised, unsupervised and hybrid classification on public pedestrian datasets with human-annotated groups, examining the effects of validation design, class imbalance, feature selection and limited labels. Fourth, it examines robustness and feasibility under simulated sensing errors, incomplete observation, privacy mechanisms and growing computational load. Together, these establish a methodological foundation for encounter-oriented urban analytics. They also identify what must be resolved before encounter classes can be read as validated behaviour: the evaluation validates companion detection against human annotation and four operational categories of the taxonomy, not all six classes.

![](figs/fig1_framework.png){width="6.5in"}

***Figure 1. The encounter identification and classification framework. The dashed arrow marks the calibration loop in which validation against external ground truth re-estimates thresholds.***

# From Movement to Encounter: Conceptual Foundations

## What Movement Data Misses

Pedestrian counters return one number per direction per interval; GPS logs return ordered positions; trajectory mining aggregates them into origin–destination patterns and dwell points (Luca et al., 2023). None of these aggregations preserves the moment at which two trajectories occupy overlapping space and time. Two pedestrians who pass within a metre of one another and a third who walks the same corridor an hour later contribute identically to a daily flow count. Figure 2 illustrates the difference on real data from one of the scenes analysed later: the movement view shows where people walk, while the encounter view shows where, and in what form, they are co-present. Questions about whether seating generates dwell, or whether a streetscape change has altered opportunities for interaction, are encounter questions and need an apparatus matched to their object.

![](figs/fig2_movement_vs_encounter.png){width="6.5in"}

***Figure 2. Movement-centric versus encounter-centric views of the same space (UCY Students scene, 216 s). (a) All tracked trajectories. (b) Midpoints of detected co-presence episodes, coloured by reference class derived from human group annotations.***

## Defining Encounter as a Computational Unit

Let $\mathbf{p}_i(t)$ be the planar position of entity $i$ at time $t$, sampled at interval $\Delta t$, and let

$$d_{ij}(t) = \lVert \mathbf{p}_i(t) - \mathbf{p}_j(t) \rVert . \qquad (1)$$

A *candidate co-presence episode* $e=(i,j,[t_0,t_1])$ is a maximal interval over which $d_{ij}(t) \le D_c$ at every observed sample, allowing gaps of at most $g$ consecutive missing or above-threshold samples, and whose duration $\tau_e = t_1 - t_0 + \Delta t$ is at least $3\Delta t$, the minimum needed to estimate velocity. $D_c$ is a generous candidate radius (3 m at the pedestrian scale); the stricter thresholds that decide whether an episode is an *encounter* of a given class are applied later and calibrated empirically. An *urban encounter* is then a candidate episode together with (a) a feature vector describing duration, density, directionality, reciprocity and spatial context, and (b) a class label assigned by the decision procedure of the taxonomy section. The definition is operational: it does not infer intent or relationship, but it does require position estimates, identity persistence and context labels, which drive the data and preprocessing decisions below.

The encounter-as-tuple view has a precedent in mobile networking, where device co-presence is modelled as a node–pair–duration–location event (Alipour et al., 2018) and BLE signal features classify proximity categories (Al Qathrady & Helmy, 2017). The urban setting differs in that co-presence is physical and densities far higher, but the apparatus carries over.

## Co-presence Is Not Interaction

A geometric definition cannot distinguish two strangers who wait side by side from two friends in conversation. Co-presence is a necessary but not sufficient condition for social interaction, and the strength of the link between the two varies with context (van Ameijde et al., 2025). The framework therefore keeps three quantities distinct: *co-presence* (geometry and time), *inferred social co-presence* (a classifier output) and *observed social relation* (external behavioural ground truth, such as human annotation of who is together). Only the third can validate the second. In the evaluation reported here, the external ground truth is human annotation of walking groups; an encounter class is credited as correct only when it agrees with that annotation, never merely because two people were close.

## Spatial Configuration as a Structural Prior

Encounters are structured by physical configuration. Space syntax showed that integration, the relative accessibility of a location within the street network, is associated with pedestrian co-presence across diverse morphologies (Hillier & Hanson, 1984; van Nes & Yamu, 2021), and the association continues to be found at the scale of individual squares and transport hubs (Johnsson & Camporeale, 2022). Integration can therefore serve as a baseline against which observed encounter densities are compared, and deviations from that baseline are candidate design signals.

The comparison must be interpreted with care. A positive residual, where observed encounter density exceeds what integration predicts, is a *correlation* between a location and an outcome after one structural covariate is accounted for. It does not show that programming, seating or any other feature of the site *caused* the excess, because unmeasured factors such as land use, timing of events, demographics or sensor coverage can produce the same residual. Causal claims require a design that supplies a counterfactual: pre/post measurement at treated and comparable untreated sites with a difference-in-differences estimator robust to staggered roll-out (Callaway & Sant'Anna, 2021), or a synthetic control built from several untreated sites when only one site is modified (Abadie, 2021). The framework uses integration as an interpretive frame for locating anomalies and leaves attribution to these designs.

# Data Sources and Preprocessing

Encounter detection draws on three categories of input: stationary sensor streams, mobile-device trajectories and computer-vision outputs from fixed cameras. Each has a different resolution, coverage and noise profile (Table 1), none is sufficient alone, and preprocessing errors propagate through the whole pipeline.

**Stationary sensors.** BLE beacons, Wi-Fi logs, infrared counters and acoustic monitors sample densely within bounded zones. The relation between received signal strength (RSSI) and distance is unreliable in crowds because of body shielding, orientation and multipath (Leith & Farrell, 2021; Su et al., 2021). Classifying proximity *categories* from RSSI and transmitted power is more portable than distance regression (Al Qathrady & Helmy, 2017), and acoustic features help further (Bahle et al., 2021). Passive Wi-Fi trajectories have been clustered to recover pedestrian groups (Koh et al., 2022; Stanitsa et al., 2023), but they sample connected devices only and raise consent questions.

**Mobile-device trajectories.** GPS gives wide coverage at low temporal resolution, with drift, multipath spikes and irregular sampling (Adhinugraha et al., 2021). It supports functional-zone and travel-mode inference (Pei et al., 2024; Wang et al., 2023), but, as the sensitivity analysis confirms, its error is too large for pedestrian-scale encounters.

**Computer vision.** YOLO-family detectors with DeepSORT-style association yield identity-persistent tracks that homography maps to metric coordinates (Sheng et al., 2024), and synchronized platforms add audio and LiDAR (Piadyk et al., 2023). Field of view, occlusion and privacy constraints are the main limitations.

**Trajectory construction and synchronization.** Every modality must yield time-ordered metric positions per entity: GPS logs are segmented at stay points, filtered and smoothed (Kalman or Savitzky–Golay), and vision tracks are projected and screened for identity switches. Clocks must be shared; NTP with post-hoc calibration bounds error at tens of milliseconds, sufficient for second-scale features.

**Table 1**

*Principal Sensing Modalities for Urban Encounter Detection*

| **Modality** | **Resolution and coverage** | **Principal quality issues** | **Analytical scale** |
|---|---|---|---|
| Stationary IoT (BLE, Wi-Fi, infrared, acoustic) | High temporal resolution within bounded zones | RSSI variability with orientation and body shielding; dropout; calibration drift (Bahle et al., 2021; Su et al., 2021) | Pedestrian to street, within instrumented zones |
| GPS and mobile-phone records | Wide coverage; ≥1–5 s sampling; 3–5 m error in urban canyons | Multipath spikes, sampling gaps, incomplete population coverage (Adhinugraha et al., 2021) | District; meso-scale mobility |
| Computer vision (YOLO/DeepSORT-class tracking) | Sub-second, sub-metre within field of view | Occlusion, identity switches, field-of-view truncation, privacy constraints (Sheng et al., 2024) | Pedestrian to street, within coverage |
| Multimodal fused sensing (e.g., StreetAware) | Synchronized video, audio, LiDAR | Hardware cost; site-specific calibration (Piadyk et al., 2023) | Pedestrian to street, instrumented sites |

# Spatiotemporal Proximity Modelling

## From Trajectories to Co-presence Events

The proximity model turns independent trajectories into pairwise events. For a spatial threshold $d_s$ and minimum duration $t_{\min}$, a pair $(i,j)$ is detected as co-present when

$$\max_{r \in R_{ij}(d_s)} |r| \, \Delta t \;\ge\; t_{\min}, \qquad (2)$$

where $R_{ij}(d_s)$ is the set of runs of samples with $d_{ij}(t) \le d_s$ after merging gaps of at most $g$ samples. Equation 2 has two free parameters whose values define the population of detected encounters. A fixed spatial threshold applied across a narrow alley, a plaza and a bus stop produces incomparable results, because the same distance carries different interactional meaning, and the threshold must also exceed the positional uncertainty of the sensing modality.

## Threshold Calibration Protocol

Thresholds are treated as parameters to be estimated, not constants. Given a calibration set of sites with external ground truth (here, annotated social groups), the protocol is: (i) evaluate Equation 2 over a grid of $d_s$ (0.5–5 m in 0.25 m steps) and $t_{\min}$ (0.4–20 s in 0.4 s steps, plus 30, 45 and 60 s); (ii) compute pair-level F1 against the ground truth at each grid point; (iii) choose

$$(\hat d_s, \hat t_{\min}) = \arg\max_{d_s, t_{\min}} \; \frac{1}{|\mathcal{C}|}\sum_{c \in \mathcal{C}} F1_c(d_s, t_{\min}), \qquad (3)$$

over the calibration sites $\mathcal{C}$; and (iv) report performance on a site *not* in $\mathcal{C}$. Leaving each site out in turn gives an estimate of how well thresholds transfer, which is the quantity a deployment at a new site actually depends on. The same protocol applies per modality, because the optimal $d_s$ for a noisy BLE distance estimate differs from that for a calibrated camera.

## Multi-scale Structure

Encounters occur at the scale of interpersonal interaction, shared occupancy of street segments and neighbourhood mobility overlap, and a single threshold across these scales conflates distinct events. The framework nests the three scales (Table 2). No modality covers all three, the values are starting points for calibration, and the evaluation below calibrates only the pedestrian scale, where external ground truth exists.

**Table 2**

*Hierarchical Proximity Model. Ranges Are Starting Points for Site-Specific Calibration*

| **Scale** | **Spatial range** | **Temporal range** | **Best-suited sensing** | **Typical analytical use** |
|---|---|---|---|---|
| Pedestrian | 0–5 m | 1 s – minutes | Computer vision; BLE | Interpersonal encounter; dwell |
| Street | 5–50 m | 1–30 min | Contiguous vision; Wi-Fi | Public-space vitality; programming |
| District | 50 m – 1 km | 30 min – hours | GPS; mobile-phone records | Mobility overlap; catchments |

## Computational Complexity

Naive pairwise evaluation costs $O(N^2)$ per frame for $N$ tracked entities. Building a k-d tree costs $O(N \log N)$, and a fixed-radius query returns the $K$ pairs within $d_s$ in $O(N \log N + K)$; a uniform grid with cell size $d_s$ gives expected $O(N + K)$. At density $\rho$ (persons m⁻²), $K \approx \tfrac{1}{2} N \rho \pi d_s^2$, so for fixed density the output, and therefore the total cost, grows linearly with $N$. Episode assembly is linear in the number of pair-frames within $D_c$, and feature extraction is linear in episode length. Cameras are independent until aggregation, so multi-camera cost is additive and parallelizable. These claims are benchmarked in the evaluation. Graph-based structures store the resulting encounter network compactly (Yau et al., 2021), and spatio-temporal graph neural networks are appropriate when the task is forecasting encounter density rather than detecting encounters (Jin et al., 2023).

# Encounter Detection and Feature Extraction

## The Detection Pipeline

Detection converts proximity signals into structured records in four steps. *Filtering* removes detections shorter than $3\Delta t$ and low-confidence tracks. *Segmentation* opens an episode when $d_{ij}$ falls below $D_c$ and closes it when the distance stays above $D_c$ for more than the gap tolerance $g$ (two samples, 0.8 s, in the evaluation), so that brief occlusions do not fragment one encounter into several. *Entity resolution* links episodes to persistent identities. *Record assembly* stores identities, times, positions, a censoring flag and the feature vector.

Three edge cases need explicit treatment. *Occlusion* fragments episodes through track loss and identity switches. *High density* satisfies the proximity condition for many pairs at once, so the pipeline records third parties co-present with both members, which keeps multi-person events from decomposing into spurious dyads (cf. Gregorj et al., 2023; Huang et al., 2026). *Sensor boundaries* truncate encounters; truncated episodes are flagged as censored ($c_e = 1$) rather than discarded, because their durations are lower bounds that call for censoring-aware analysis.

## Feature Dimensions

Each episode is described by 19 features in five dimensions (Table 3). Speeds $s_i(t)=\lVert\mathbf{v}_i(t)\rVert$ are computed by central differences on the actual sample times, after smoothing when positions are noisy, and episode means are denoted by bars. Spatial context is represented here by three site-agnostic proxies, local flow speed, normalized occupancy and distance from the edge of the used space, because the public benchmark lacks semantic labels; deployments with street-level imagery can add function-zone and furniture labels from semantic segmentation (Niu et al., 2022).

**Table 3**

*Feature Definitions (Episode e Between i and j; Means Over the Episode)*

| **Dimension** | **Features** | **Definition** |
|---|---|---|
| Duration and dwell | $\tau_e$, $\log\tau_e$, censoring flag $c_e$, stationary fraction $f_{\text{stat}}$ | $f_{\text{stat}}$ = share of samples with $s_i, s_j < v_s$ |
| Density | $\overline{d}$, $\min d$, $\sigma_d$, ambient count $\overline{n}_5$, third parties $n_3$ | $\overline{n}_5$ = others within 5 m of the pair midpoint; $n_3$ = others within $D_c$ of both for ≥50% of samples |
| Directionality | heading alignment $\overline{c}$, relative speed $\overline{\Delta v}$, approach rate, mean speed $\overline{v}$ | $\overline{c}$ = mean cosine between velocity vectors while both move; approach = $(d(t_1)-d(t_0))/\tau_e$ |
| Reciprocity | speed correlation $r_s$, speed difference $\overline{|s_i-s_j|}$, co-stop fraction | $r_s$ = Pearson correlation of $s_i(t)$ and $s_j(t)$ |
| Spatial context | ambient flow speed, occupancy prior, edge distance | ambient flow = mean speed of others within 5 m; occupancy = normalized visit density of the 1 m cell |

The dimensions are correlated (duration and density co-vary in crowds), but each captures a distinct facet: velocity convergence and heading alignment separate companions from strangers who share a corridor; local density conditions pedestrian behaviour strongly enough that density-aware models predict trajectories better (Korbmacher & Tordeux, 2024); reciprocity captures synchronized adjustment such as stopping together (Stanitsa et al., 2023); and context separates a 90-second wait at a bus stop from a 90-second conversation at a café entrance. Whether they provide *complementary* predictive value is tested by ablation below.

Edge cases follow fixed conventions. Features are computed over the samples at which both members are observed; gaps of up to $g$ samples are bridged, and velocity uses the true time step across a gap. Heading alignment $\overline{c}$ is averaged only over samples where both speeds exceed 0.2 m s⁻¹ and is set to 0 when there are none, so it is undefined rather than spurious for stationary pairs. The speed correlation $r_s$ is set to 0 when an episode has fewer than three samples or either speed series is constant. Ambient flow speed is set to 0 when no other person is within 5 m at any sample. An episode is flagged as censored when it touches the first or last common sample of the pair.

# Encounter Taxonomy and Decision Boundaries

## Formal Decision Procedure

The taxonomy has six classes: five behavioural classes and a reject class. Duration-band definitions leave classes overlapping. Here the classes are defined by a sequence of explicit tests, shown in Figure 3, so that every episode receives exactly one label and the order of the tests resolves overlaps. Social co-presence is defined as

$$S(e) = [\overline{d} \le \theta_d] \wedge [\tau_e \ge \theta_\tau] \wedge [\overline{\Delta v} \le \theta_v] \wedge \big([\overline{c} \ge \theta_c] \vee [f_{\text{stat}} \ge \tfrac12]\big). \qquad (4)$$

The heading condition applies only to moving pairs, which is why it is combined by disjunction with the stationary fraction. The class $y(e)$ is then

$$y(e)=\begin{cases}
6\ \text{Unclassified} & \text{if } \exists k: |x_k - \theta_k| < \delta_k \text{ or } \max_c p(c\mid \mathbf{x}) < \rho\\
1\ \text{Transit Crossing} & \text{if } \neg S(e)\\
5\ \text{Companionate Movement} & \text{if } S(e) \wedge \overline{v} \ge v_s\\
4\ \text{Group Encounter} & \text{if } S(e) \wedge \overline{v} < v_s \wedge n_3 \ge 1\\
3\ \text{Sustained Dyadic} & \text{if } S(e) \wedge \overline{v} < v_s \wedge n_3 = 0 \wedge \tau_e \ge \tau_S\\
2\ \text{Brief Encounter} & \text{otherwise.}
\end{cases} \qquad (5)$$

Default values are $v_s = 0.5$ m s⁻¹ and $\tau_S = 180$ s (following Chen et al., 2025), fixed a priori rather than calibrated. The thresholds $\theta = (\theta_d, \theta_\tau, \theta_v, \theta_c)$ are calibrated as in Equation 3 by maximizing macro-F1 on calibration sites over the grid $\theta_d \in \{0.75,1,1.25,1.5,2\}$ m, $\theta_\tau \in \{2,4,6,8\}$ s, $\theta_c \in \{-1, 0.5, 0.8, 0.9\}$ and $\theta_v \in \{0.3, 0.5, 1, \infty\}$ m s⁻¹.

![](figs/fig3_taxonomy.png){width="5.6in"}

***Figure 3. The six-class taxonomy as an explicit decision procedure. Each episode follows exactly one path; the order of tests resolves overlaps between classes.***

## Resolving Ambiguous and Overlapping Cases

The procedure resolves the four overlaps that a duration-band taxonomy leaves open. (i) *Brief Encounter versus Sustained Dyadic* differ only in duration, split at $\tau_S$; because observed durations are censored at sensor boundaries, an episode with $c_e = 1$ and $\tau_e < \tau_S$ is a lower bound and should be reported as "Brief (censored)" rather than silently assigned. (ii) *Dyadic versus Group*: a pair belonging to a larger stationary cluster is labelled Group, because $n_3$ is tested before duration; group membership takes precedence over pairwise duration. (iii) *Group versus Companionate*: the speed test precedes the group test, so a moving cluster of three or more is Companionate Movement and becomes a Group Encounter if it stops. In deployment, an episode that switches state should be split at the change point of a sliding-window $\overline{v}$; the evaluation below scores whole episodes. (iv) *Social versus transit* is decided by Equation 4 alone; an episode that is close and long but shows misaligned headings and unequal speeds remains Transit Crossing.

Class 6 is a *reject option* rather than a residual behavioural type. An episode is withheld when any deciding feature lies within a margin $\delta_k$ of its threshold (for the rule-based classifier) or when the maximum class posterior falls below $\rho$ (for a probabilistic classifier). Withheld episodes are reported, not dropped, so that downstream densities can be bounded.

Thresholds enter at five stages of the pipeline, which differ in how they are set and whether they are expected to vary between sites (Table 4). The six classes form the proposed conceptual taxonomy. Which of them the benchmark can validate is stated in Table 6 of the evaluation.

**Table 4**

*Thresholds by Pipeline Stage*

| **Stage** | **Thresholds** | **How set** | **Behaviour across sites in the benchmark** |
|---|---|---|---|
| Candidate generation | $D_c$ = 3 m, $g$ = 2 samples, minimum 3 samples | Fixed a priori; label-free | Not tuned |
| Pair-level detection (Eq. 2) | $d_s$, $t_{\min}$ | Calibrated against annotated groups (Eq. 3) | Vary: 0.75–2.25 m and 1.2–8.8 s at the optimum |
| Social co-presence (Eq. 4) | $\theta_d$, $\theta_\tau$, $\theta_v$, $\theta_c$ | Grid search on training sites for macro-F1 | Selected values stable across folds |
| Class boundaries (Eq. 5) | $v_s$, $\tau_S$, $n_3 \ge 1$ | Fixed a priori from the literature | Not tuned; $v_s$ also defines reference labels |
| Reject option | $\delta_k$, $\rho$ | Chosen for a required coverage | Trade-off reported |


# Experimental Setup

## Data and Ground Truth

The evaluation uses the five most widely used public pedestrian sequences that carry human annotations of social groups: ETH and Hotel, recorded in Zurich (Pellegrini et al., 2009), and Zara01, Zara02 and Students, recorded in Nicosia (Lerner et al., 2007), in the versions distributed by the OpenTraj benchmark (Amirian et al., 2020). Trajectories are given in metres at 0.4 s intervals. Each sequence lists the pedestrians that annotators judged to be walking together. Table 5 summarizes the scenes, which span a sevenfold range of mean occupancy and four settings.

**Table 5**

*Benchmark Scenes, Ground Truth and Detected Episodes*

| **Scene** | **City, setting** | **Duration (s)** | **Persons** | **Persons/frame** | **Median NN distance (m)** | **Annotated group pairs** | **Candidate episodes (social)** |
|---|---|---|---|---|---|---|---|
| ETH | Zurich, building forecourt | 774 | 360 | 6.2 | 1.27 | 166 | 1,162 (164) |
| Hotel | Zurich, hotel sidewalk | 723 | 390 | 5.6 | 1.22 | 47 | 922 (47) |
| Zara01 | Nicosia, shopping street | 361 | 148 | 5.8 | 1.00 | 73 | 440 (76) |
| Zara02 | Nicosia, shopping street | 421 | 204 | 9.1 | 0.81 | 70 | 1,059 (70) |
| Students | Nicosia, campus plaza | 216 | 428 | 40.5 | 0.70 | 168 | 5,465 (178) |
| **Total** | | 2,495 | 1,530 | | | 524 | 9,048 (535) |

*Note.* NN = nearest neighbour. Annotated group pairs are pairs of members of the same annotated group that are co-observed in at least one frame. Social episodes are candidate episodes between two such members: 521 of the 524 pairs produced at least one episode, 13 produced two or more because the members separated beyond 3 m and rejoined, and 3 never came close enough, giving 535 social episodes.

Candidate episodes were extracted with $D_c = 3$ m, $g = 2$ samples and a minimum of three samples. Only 535 of the 9,048 candidate co-presence episodes (5.9%) involve annotated companions, a direct measure of how weakly co-presence alone indicates a social relation. Reference labels for the taxonomy combine the annotation with kinematics. An episode between non-companions is *Transit Crossing*. One between companions is *Companionate Movement* if the pair's mean speed is at least $v_s = 0.5$ m s⁻¹, and otherwise a *Group Encounter* if another member of the same annotated group is within $D_c$ of both for at least half the episode, or a *stationary dyad* if not. The resulting distribution is highly imbalanced: 8,513 Transit, 463 Companionate, 57 Group and 15 dyadic episodes, with 48 of the 57 Group and 9 of the 15 dyadic episodes in the Students scene.

## Evaluation Objectives

The labels support two different claims, and the evaluation keeps them apart.

*Objective A, externally validated companion detection.* Labels come from the human annotation alone. Two tasks qualify: social F1, which separates episodes between annotated companions from all others, and an annotation-only three-class task that separates Transit Crossing, companions in a group of two (245 episodes) and companions in a group of three or more (290 episodes) using annotated group size. Agreement on these tasks is independent evidence that the method recognizes who is together.

*Objective B, reproduction of the operational taxonomy.* The four-class reference labels share definitions with the classifier. The mean-speed variable $\overline{v}$ that separates moving from stationary companions in the labels is the same variable tested in Equation 5. The third-party test $n_3 \ge 1$ counts any nearby person, whereas the Group label counts only annotated members, but the two agree on 66 of the 72 stationary social episodes (92%). Macro-F1 on these labels therefore measures how consistently a method implements the taxonomy, not independent behavioural validity. Human annotation validates only the social-versus-transit decision within them.

Table 6 states which classes of the taxonomy each label set can test. The six-class taxonomy is the proposed framework; the experiments provide partial empirical validation of it.

**Table 6**

*Proposed Taxonomy Classes and Their Evaluation Status in the Benchmark*

| **Proposed class** | **Reference label** | **Evaluation status** |
|---|---|---|
| 1 Transit Crossing | Co-presence of non-companions (annotation) | Evaluated against annotation (8,513 episodes) |
| 5 Companionate Movement | Companions with $\overline{v} \ge v_s$ | Companion part validated against annotation; moving/stationary split definitional (463) |
| 4 Group Encounter | Stationary companions with another member nearby | Evaluated with limited examples (57, of which 48 in one scene) |
| 2 Brief Encounter | Stationary companion dyad, $\tau_e < \tau_S$ | Not separately validated: evaluated jointly with class 3 as "stationary dyad" (15) |
| 3 Sustained Dyadic | Stationary companion dyad, $\tau_e \ge \tau_S$ | Not separately validated: only 2 of 9,048 episodes reach 180 s |
| 6 Unclassified | None | Evaluated as an abstention mechanism (coverage versus accuracy) |

*Note.* Meetings between people who arrive separately, a common form of Brief Encounter, are not annotated in these data and are counted as Transit Crossing.

## Protocol

**Validation designs.** Every model is evaluated under three designs: (i) stratified random 5-fold cross-validation over episodes, the design most often reported; (ii) temporal block validation, which splits each scene into five contiguous time blocks, tests on one block and trains on the others after removing a one-block buffer on each side; and (iii) leave-one-scene-out (LOSO) validation, which trains on four scenes and tests on the fifth. Random splits place episodes of the same pair, place and minute on both sides of the split, a recognized form of leakage (Kapoor & Narayanan, 2023) that inflates accuracy relative to prediction at new locations (Meyer & Pebesma, 2022). LOSO is the primary design.

**Models.** Six classifiers were compared. (1) *Rule-based*: Equations 4–5 with $\theta$ chosen on the training scenes by grid search over 320 combinations. (2) *Logistic regression*: standardized features, $C = 1$. (3) *Random forest*: 500 trees, minimum leaf size 2, $\sqrt{p}$ features per split. (4) *Gradient boosting*: histogram-based, 300 iterations, learning rate 0.05, 15 leaves. (5) *Unsupervised GMM*: full-covariance Gaussian mixture, 2–12 components chosen by BIC, components mapped to classes by class-balanced majority vote of training labels. (6) *Hybrid*: the GMM fitted to all training episodes, confident components ($p \ge 0.9$) used to pseudo-label unlabelled episodes, and a random forest trained on labelled and pseudo-labelled episodes with GMM posteriors as extra features. All learned models used balanced class weights, and the rule's thresholds maximize macro-F1, so every method is optimized for the imbalanced classes. Hyperparameters were fixed a priori. No probability calibration was applied.

**Metrics and statistics.** For Objective B, the metric is macro-F1 over the four reference classes; the reject class (class 6) is not part of it, and no episode is withheld except in the reject-option analysis. For Objective A, the metrics are social F1 and three-class macro-F1. Confidence intervals are 95% percentile intervals from 1,000–2,000 bootstrap resamples of pedestrian *pairs* (a cluster bootstrap, because a pair's episodes are dependent). Differences between models or configurations are reported as the observed difference with a paired cluster-bootstrap interval; accuracy is also compared with McNemar's test. The unit of analysis is the candidate episode, except in threshold calibration, where it is every pair of co-observed pedestrians, so that annotated pairs that never meet the proximity condition count as misses.

## Leakage Prevention and Fold-Specific Preprocessing

The candidate-episode population is fixed before any fold is formed. Episodes are extracted with label-free constants ($D_c$, $g$, minimum length) chosen a priori, and annotations enter only the reference labels. All methods and validation designs are therefore scored on the same 9,048 episodes.

Within each fold, every fitted quantity is estimated from training scenes only. This covers standardization and Yeo–Johnson transforms, GMM components and their class mapping, class weights, the rule's thresholds $\theta$, and the $(d_s, t_{\min})$ pairs in the calibration experiment. Fitting the rule is itself the threshold selection, so no test-scene score enters any choice. The robustness check over eight random-forest configurations reports held-out scores but was not used for selection.

Features of a held-out scene do use its unlabelled trajectories. Ambient density, third parties and flow use concurrent frames only, but the occupancy prior and edge distance are normalized over the whole recording, a transductive use of unlabelled data that a deployment would replace with an earlier period. The effect is bounded: the rule uses neither feature, and removing the context group from the random forest changed macro-F1 by +0.029 (95% CI −0.009 to +0.080) and social F1 by −0.026. In the sensitivity experiments, perturbations are applied before episode extraction, so each condition has its own episode population, while reference labels are always computed from the clean annotated tracks.

## Reproducibility

Experiments used Python 3.13, scikit-learn 1.9 and SciPy 1.18 with fixed random seeds. Scripts, result files and step-by-step instructions are provided as supplementary material and at [repository URL to be inserted]; they regenerate every table and figure from the public data in under an hour on a two-core machine.

# Results

## Threshold Calibration and Deployment

Figure 4 shows pair-level F1 against annotated groups across the $(d_s, t_{\min})$ grid, computed on the annotated (camera-grade) trajectories. Optimal thresholds differ between scenes: $d_s$ from 0.75 m (Hotel) to 2.25 m (ETH) and $t_{\min}$ from 1.2 s to 8.8 s, with scene-optimal F1 between 0.78 and 0.90. Thresholds calibrated on the other four scenes (Equation 3; $d_s$ = 1.25 m in four folds and 1.5 m in one, $t_{\min}$ = 5.6–6.0 s) achieved a mean held-out F1 of 0.76 (range 0.64–0.90), a transfer loss of 0.00–0.16. The largest losses occurred in the densest scene (Students), where 1.5 m was too permissive at a median nearest-neighbour distance of 0.70 m, and in ETH, where companions walked further apart (median separation 1.18 m against 0.70–1.00 m elsewhere). Literature-style defaults performed poorly: $d_s$ = 1.5 m with $t_{\min}$ = 60 s found almost no groups (F1 0.00–0.15), because few encounters stay inside a camera's view for a minute.

![](figs/fig4_threshold_calibration.png){width="6.5in"}

***Figure 4. Threshold calibration against annotated groups. Panels 1–5: pair-level F1 over spatial threshold d_s and minimum duration t_min for each scene on annotated trajectories; ★ marks the scene-optimal pair, ○ the pair calibrated on the other four scenes. Panel 6: held-out F1 of the transferred thresholds when the calibration is repeated on each simulated sensing modality (points are scenes, bars are means).***

The calibration was repeated on three simulated modalities: camera tracks with 0.15 m noise; BLE distances from a log-distance path-loss model with 6 dB temporally correlated shadowing and a 5 dB body-shielding loss for half the pairs; and GPS fixes at 1.2 s intervals with 4 m autocorrelated error. Mean held-out F1 was 0.70 for camera, 0.48 for BLE, with the optimal $d_s$ shifted to 2–5 m, and 0.20 for GPS. Thresholds are thus no more portable across modalities than across sites.

Scene-to-scene variation of $(d_s, t_{\min})$ and the stability of $\theta$ (next subsection) are not in conflict, because they belong to different stages (Table 4) with different units, objectives and grid resolutions. The pair-level test applies $d_s$ to instantaneous distance alone. Equation 4 applies $\theta_d$ to the episode mean distance jointly with three other conditions, on a coarser grid.

The results support a three-tier deployment protocol. *Zero-label deployment* at a new site with camera-grade tracks can use the transferred values ($d_s$ ≈ 1.25 m, $t_{\min}$ ≈ 6 s) or a density-adaptive radius $d_s = \kappa \cdot$ (median nearest-neighbour distance) estimated without labels. With $\kappa$ and $t_{\min}$ calibrated on the other scenes ($\kappa$ = 1.3–1.6, $t_{\min}$ = 5.6–6.0 s), the adaptive rule raised mean held-out F1 from 0.76 to 0.78 and Students from 0.64 to 0.80, but lowered Hotel from 0.76 to 0.65; it is a reasonable default for dense sites, not a uniform improvement. *Limited-label calibration*, annotating a sample of local episodes, re-estimates $\theta$ and $(d_s, t_{\min})$; in the label-budget experiment below, 1–2% of training episodes brought the rule to macro-F1 0.65–0.68, against 0.72 with all labels. *Full calibration* recovers scene-optimal thresholds. A change of sensor requires recalibration in every tier.

## Classification Performance and Validation Design

Table 7 and Figure 5 report the six classifiers under the three validation designs on Objective B. Under random 5-fold validation the learned models led: gradient boosting reached macro-F1 0.79 and the random forest 0.76, against 0.72 for the rule-based procedure. Under LOSO the ranking reversed: the rule-based procedure was unchanged (0.72), whereas the random forest fell to 0.49 and gradient boosting to 0.50. The 0.27 gap between the random and LOSO estimates for the random forest is the optimism that random cross-validation would have reported.

**Table 7**

*Macro-F1 (Objective B) and Social F1 (Objective A), With 95% Pair-Cluster Bootstrap CIs*

| **Classifier** | **Random 5-fold macro-F1** | **Temporal block macro-F1** | **LOSO macro-F1** | **LOSO social F1** |
|---|---|---|---|---|
| Rule-based (Eqs. 4–5) | 0.72 (0.65–0.77) | 0.70 (0.63–0.75) | **0.72 (0.66–0.78)** | **0.76 (0.73–0.79)** |
| Logistic regression | 0.55 (0.51–0.60) | 0.54 (0.49–0.58) | 0.43 (0.40–0.46) | 0.53 (0.51–0.56) |
| Random forest | 0.76 (0.68–0.83) | 0.71 (0.62–0.77) | 0.49 (0.44–0.54) | 0.73 (0.70–0.76) |
| Gradient boosting | 0.79 (0.72–0.85) | 0.65 (0.58–0.71) | 0.50 (0.45–0.54) | 0.72 (0.69–0.75) |
| Unsupervised GMM | 0.39 (0.38–0.41) | 0.39 (0.37–0.40) | 0.37 (0.35–0.39) | 0.34 (0.32–0.36) |
| Hybrid (GMM + RF) | 0.75 (0.66–0.82) | 0.70 (0.61–0.77) | 0.49 (0.44–0.55) | 0.72 (0.69–0.76) |

*Note.* Macro-F1 is over the four reference classes; the reject class is excluded and no episodes are withheld.

![](figs/fig5_validation_confusion.png){width="6.3in"}

***Figure 5. (a) Macro-F1 of the same classifiers under three validation designs. (b, c) Row-normalized LOSO confusion matrices (counts in parentheses) for the rule-based procedure and the random forest.***

The confusion matrices locate the difference. Both approaches recognized Transit Crossing (F1 0.98) and Companionate Movement (F1 0.77 rule-based, 0.78 random forest) comparably. They diverged on the stationary classes: the rule-based procedure recovered 82% of Group Encounters and 47% of stationary dyads, the random forest none and 13%. Under LOSO the rule-based macro-F1 exceeded the random forest's by 0.23 (paired bootstrap 95% CI 0.16–0.30, *p* < 0.001), while overall accuracy was indistinguishable (McNemar *p* = 1.00) because the majority class dominates it. The rule's thresholds were stable: every fold selected $\theta_d$ = 1.5 m, $\theta_\tau$ = 6 s and $\theta_v$ = 0.3 m s⁻¹, and four of five selected $\theta_c$ = 0.5. The random forest's results were insensitive to its hyperparameters (LOSO macro-F1 0.49–0.55 across eight configurations).

This advantage must be read against the evaluation objectives. Among correctly detected social episodes, the rule's moving-versus-stationary assignment agreed with the labels in 100% of cases by construction, because label and rule use the same $\overline{v}$; the random forest agreed in 99%. On Objective A the advantage shrank and was not significant. Social F1 was 0.76 against 0.73 (difference +0.027, 95% CI −0.002 to +0.055, *p* = 0.07). On the annotation-only three-class task, macro-F1 was 0.68 (0.66–0.71) against 0.66 (0.63–0.68), a difference of +0.024 (−0.010 to +0.058, *p* = 0.17); the rule was better on larger groups (F1 0.44 against 0.25) and the random forest on pairs (0.74 against 0.63).

The defensible conclusion is narrow. Explicit rules reproduced the operational taxonomy more robustly across these five scenes, partly because their boundaries share definitions with the labels. For recognizing annotated companions, rule-based and learned classifiers were statistically indistinguishable. The ranking also reflects a small, imbalanced benchmark: when Students is held out, the training scenes contain only nine Group and six dyadic examples. Additional sites with stationary groups could change the ranking, as the learned models' lead under random cross-validation, where every scene contributes training data, suggests.

## Hybrid Versus Supervised and Unsupervised Learning

The hybrid did not outperform supervised learning. With full labels it was statistically indistinguishable from the random forest under LOSO (macro-F1 difference +0.003, 95% CI −0.002 to +0.015, *p* = 0.44; McNemar *p* = 0.40), and the unsupervised GMM was clearly worse than both (−0.12 relative to the hybrid, 95% CI −0.18 to −0.07). Figure 6 repeats the comparison at label budgets of 1–100% of training episodes, with five random draws each. Below 100%, the hybrid's pseudo-labels inherited the GMM's poor alignment with the classes: its macro-F1 (0.35–0.43) tracked the unsupervised model rather than the random forest (0.49–0.53). The rule-based procedure, which estimates four thresholds, reached 0.65 with 1% of labels and led at every budget on Objective B. In this benchmark, hybrid learning is therefore useful only for exploratory typology discovery, with clusters inspected by analysts rather than used as labels.

![](figs/fig6_label_budget.png){width="6.5in"}

***Figure 6. LOSO performance as a function of the labelled share of training episodes (mean ± one standard deviation over five draws).***

## Ablation: Do the Feature Dimensions Add Complementary Value?

Both ablations re-fitted thresholds or models for every configuration under LOSO (Table 8). In the rule, distance and the third-party test mattered most (macro-F1 −0.12 and −0.23), reciprocity and duration about −0.04 each, and heading/dwell −0.008. In the random forest, density and context features mattered for social F1 (−0.07 and −0.03), whereas duration, directionality and reciprocity were largely interchangeable. No single dimension sufficed.

**Table 8**

*LOSO Ablation. Observed Change Relative to the Full Model With 95% Paired Bootstrap CIs*

| **Model** | **Configuration** | **Macro-F1** | **Δ macro-F1 (95% CI)** | **Social F1** | **Δ social F1 (95% CI)** |
|---|---|---|---|---|---|
| Rule-based | Full rule | 0.719 | — | 0.760 | — |
| Rule-based | Distance condition removed (density) | 0.597 | −0.122 (−0.148 to −0.098) | 0.620 | −0.140 (−0.168 to −0.112) |
| Rule-based | Duration condition removed | 0.680 | −0.039 (−0.085 to +0.007) | 0.739 | −0.020 (−0.047 to +0.004) |
| Rule-based | Speed-difference condition removed (reciprocity) | 0.683 | −0.036 (−0.075 to −0.002) | 0.742 | −0.018 (−0.045 to +0.006) |
| Rule-based | Heading/dwell condition removed (directionality) | 0.711 | −0.008 (−0.017 to 0.000) | 0.755 | −0.005 (−0.011 to +0.001) |
| Rule-based | Third-party test removed (density) | 0.486 | −0.232 (−0.287 to −0.174) | 0.728 | −0.032 (−0.051 to −0.013) |
| Random forest | All features | 0.489 | — | 0.732 | — |
| Random forest | Duration features removed | 0.514 | +0.026 (−0.005 to +0.081) | 0.725 | −0.007 (−0.023 to +0.006) |
| Random forest | Density features removed | 0.479 | −0.010 (−0.042 to +0.033) | 0.661 | −0.071 (−0.096 to −0.043) |
| Random forest | Directionality features removed | 0.508 | +0.019 (−0.012 to +0.067) | 0.738 | +0.006 (−0.011 to +0.021) |
| Random forest | Reciprocity features removed | 0.506 | +0.017 (−0.009 to +0.062) | 0.738 | +0.006 (−0.007 to +0.019) |
| Random forest | Context features removed | 0.518 | +0.029 (−0.009 to +0.080) | 0.706 | −0.026 (−0.041 to −0.012) |
| Random forest | Only density features | 0.406 | −0.083 (−0.142 to −0.033) | 0.693 | −0.039 |
| Random forest | Only directionality features | 0.453 | −0.036 (−0.076 to +0.006) | 0.628 | −0.103 |
| Random forest | Only duration features | 0.436 | −0.053 (−0.126 to +0.012) | 0.481 | −0.251 |
| Random forest | Only reciprocity features | 0.360 | −0.129 (−0.184 to −0.066) | 0.270 | −0.462 |
| Random forest | Only context features | 0.284 | −0.205 (−0.265 to −0.153) | 0.153 | −0.579 |

*Note.* Δ is the observed difference computed from unrounded scores, so it can differ by 0.001 from the difference of the displayed values. CIs are percentile intervals of the paired cluster-bootstrap distribution over pedestrian pairs (1,000 resamples); none was computed for single-dimension social F1.

## How Many Classes Does the Feature Space Support?

Unsupervised criteria did not identify a natural number of classes. After a Yeo–Johnson transform of the 19 features, GMM BIC decreased up to eleven components, the k-means silhouette was low at every *k* (0.14–0.17), bootstrap stability peaked at *k* = 5–6 (ARI 0.96 and 0.92), and agreement with the reference classes stayed poor (k-means ARI ≤ 0.07; GMM ARI ≤ 0.26). The number of classes is therefore a design decision, five behavioural distinctions plus a reject option, whose individual tests can be checked by ablation. Four of the tests were supported; the duration split between Brief and Sustained encounters could not be tested.

## Reject Option (Class 6)

Thresholding the random forest's uncalibrated maximum posterior at $\rho$ = 0.6 withheld 2% of episodes and raised social F1 on the accepted episodes from 0.73 to 0.78; at $\rho$ = 0.9 coverage fell to 89% and social F1 rose to 0.86. The reject option is not neutral: at $\rho$ = 0.9 it withheld 93% of stationary dyads and 81% of Group Encounters but only 8% of Transit Crossings. Unclassified episodes must therefore be reported with their composition, because discarding them removes precisely the rare social classes.

## Sensitivity to Sensing Conditions

Each factor was varied with the others at baseline, and the rule-based procedure and a random forest were re-fitted under LOSO for every condition (Figure 7). Because each condition requires re-extracting episodes and re-training all folds, the random forest used 200 trees here. Its baseline was recomputed with the same configuration (macro-F1 0.51, social F1 0.73, against 0.49 and 0.73 with 500 trees), so comparisons are within one configuration.

*Positional error* (AR(1) noise, ρ = 0.9, followed by Savitzky–Golay smoothing) up to 0.25 m left social F1 essentially unchanged (0.73–0.77). At 0.5 m rule-based macro-F1 fell to 0.48, at 1 m social F1 fell to about 0.37 for both models, and at 4 m, the GPS regime, detection failed (0.08 and 0.00). *Sampling intervals* of up to 4 s preserved social F1 (0.74–0.77), but the number of episodes fell from 9,048 to 2,295 and the censored share rose from 46% to 85%. *Occlusion with identity switches* (mean 2 s, half followed by a new identity) reduced rule-based macro-F1 from 0.72 to 0.57 at a hazard of 0.05 per frame, about one occlusion every 8 s per person, while random-forest social F1 stayed at 0.71. *Field-of-view truncation* to 40% of the extent raised the censored share to 86% and cut the median observed duration of social episodes from 12.0 s to 4.4 s, an underestimate of 63%. Classification scores on truncated data are not comparable across layouts, because the evaluated episode population changes.

*BLE shadowing* was repeated with three seeds per level. Mean held-out F1 of the calibrated detector was 0.60 ± 0.07 (mean ± SD) at 2 dB, 0.53 ± 0.03 at 4 dB, 0.54 ± 0.05 at 6 dB, 0.44 ± 0.03 at 8 dB and 0.37 ± 0.03 at 10 dB, with the calibrated $d_s$ at 2.0–2.5 m. The single 6 dB runs reported earlier (0.48 and 0.54) lie within the seed-to-seed range of 0.49–0.58.

*Device penetration* matters when both people must carry a device. Uniform penetration $q$ scaled counts by $q^2$, which weighting by $1/(q_i q_j)$ corrected to within 1%. Penetration of 0.3 for companions and 0.6 for solitary pedestrians biased the naive social share by −48%, and the reverse by +53%; weighting removed both biases only because the rates were known.

![](figs/fig7_sensitivity.png){width="6.0in"}

***Figure 7. Sensitivity of LOSO performance to (a) positional error, (b) sampling interval, (c) occlusion with identity switches and (d) field-of-view truncation.***

## Privacy-Preserving Mechanisms

**Threat model.** The protected unit is a person, meaning all the episodes they take part in. The released output is a map of encounter counts per 2 m cell for one recording. The adversary is any recipient of the map, with arbitrary auxiliary knowledge. For federated learning, the adversary is an honest-but-curious server that sees every round's model updates, with no secure aggregation.

**Differentially private hotspot release.** Following recent practice for mobility data (Kohli et al., 2024), Laplace noise of scale $1/\varepsilon_e$ was added to every cell. Datasets differing in one episode change one cell by one, so the release is $\varepsilon_e$-differentially private at the episode level (Near et al., 2025). A person involved in $d$ episodes is protected at $d\,\varepsilon_e$ by group privacy. Observed degrees were a median of 7 episodes per person, 38 at the 95th percentile and 139 at most (median 22 in Students). At $\varepsilon_e$ = 0.1, the median person therefore has $\varepsilon$ = 0.7, the 95th-percentile person 3.8 and the most exposed person 13.9. Utility at that budget remained useful: on average 87% of the ten leading hotspot cells were recovered and the noisy and true maps correlated at Spearman ρ = 0.78. At $\varepsilon_e$ = 0.25 the figures were 95% and 0.88, and at $\varepsilon_e$ = 1, 98% and 0.96. Each released map consumes its budget, so maps of overlapping populations compose additively (Near et al., 2025). Capping each person's episodes greedily does not by itself bound person-level sensitivity, because removing one person frees capacity for their partners' other episodes; a uniform person-level guarantee requires a node-level mechanism with proven sensitivity.

**Federated learning.** Federated learning keeps raw data on site and shares model parameters (Kairouz et al., 2021; Pandya et al., 2023). Each training scene acted as a FedAvg site for a 19–32–4 multilayer perceptron (40 rounds, one local epoch, LOSO, three seeds). The federated model (macro-F1 0.46) matched a centrally trained model of the same architecture (0.43) and exceeded single-site models (mean 0.41). Plain FedAvg offers no formal guarantee, and model updates can leak information about training records. Adding DP-SGD at each site (per-example clipping at norm 1, Gaussian noise, Poisson subsampling, Rényi accountant, δ = 10⁻⁵) cost 0.01–0.02 macro-F1. It gave ε ≈ 18 at noise multiplier 1 and ε ≈ 6 at noise multiplier 2 per *episode*, and a far weaker person-level guarantee by group privacy. Communication totalled 4.9 MB over five folds, more than uploading this small benchmark's raw trajectories (0.6 MB), so federation buys data minimization, not bandwidth. Per-example clipping roughly doubled compute (2.4–2.7 s against 1.2 s per run).

**Table 9**

*Privacy Mechanisms: Utility, Guarantee and Cost*

| **Mechanism** | **Setting** | **Utility** | **Guarantee (protected unit)** | **Overhead** |
|---|---|---|---|---|
| DP hotspot map | $\varepsilon_e$ = 0.1 | Top-10 recall 0.87; ρ = 0.78 | 0.1 per episode; 0.7 median person, 3.8 at 95th percentile | ≈5 µs per map |
| DP hotspot map | $\varepsilon_e$ = 0.25 | Top-10 recall 0.95; ρ = 0.88 | 0.25 per episode; 1.8 median person, 9.5 at 95th percentile | ≈5 µs per map |
| DP hotspot map | $\varepsilon_e$ = 1 | Top-10 recall 0.98; ρ = 0.96 | 1 per episode; 7 median person, 38 at 95th percentile | ≈5 µs per map |
| Federated MLP (FedAvg) | 4 sites, 40 rounds | Macro-F1 0.46 (central 0.43; single site 0.41) | None formal; raw data stay on site | 4.9 MB; 1.2 s |
| Federated MLP + DP-SGD | Noise multiplier 1 | Macro-F1 0.45 | (ε ≈ 18, δ = 10⁻⁵) per episode | 4.9 MB; 2.6 s |
| Federated MLP + DP-SGD | Noise multiplier 2 | Macro-F1 0.44 | (ε ≈ 6, δ = 10⁻⁵) per episode | 4.9 MB; 2.7 s |

## Scalability

Candidate-pair search was benchmarked on synthetic frames of $N$ = 10² to 10⁶ entities at 0.2 persons m⁻² with $d_s$ = 2 m (Figure 8). Brute force scaled with log–log slope 2.0 (15.5 s and about 460 MB per frame at $N$ = 30,000). A k-d tree scaled with slope 1.06 and processed one million entities in 0.57 s per frame with a peak memory increase of 67 MB. Candidate pairs per person matched the expectation $\rho\pi d_s^2$ to within 4% between 0.01 and 1 person m⁻². End-to-end, the pipeline processed the densest scene at 7.6–8.0 times real time per camera on one core. Total time grew linearly from 1 to 8 camera streams (28.5 s to 217 s) at constant memory (21–23 MB), and classification ran at about 210,000 episodes per second, so feature extraction rather than proximity search dominates cost.

![](figs/fig8_scalability.png){width="6.3in"}

***Figure 8. Scalability of candidate-pair search on synthetic frames at 0.2 persons per m²: (a) time per frame, (b) peak resident-memory increase.***

## Summary of Evidence

Within this five-scene benchmark and its label-sampling experiments, the evidence supports six qualified conclusions. Thresholds should be calibrated per site and sensor; camera-grade defaults transferred with losses of up to 0.16 F1. Leave-one-site-out validation should be the reporting standard, because random cross-validation overstated learned models by about 0.27 macro-F1. Explicit rules reproduced the operational taxonomy more robustly than learned models, but recognized annotated companions no better. Hybrid learning gave no measurable gain. Four of the five decision tests were supported by ablation. Positional accuracy better than about 0.5 m and censoring-aware duration analysis are preconditions for pedestrian-scale analysis, and privacy mechanisms must be reported with their protected unit and budget.


# Translating Encounter Intelligence Into Design Decisions

The benchmark supports a small but real spatial analysis of the question designers ask: do places of high pedestrian flow coincide with places where companions meet and linger? For each scene, pedestrian presence (person-minutes per 2 m cell) was compared with the duration of episodes that the rule-based classifier, under LOSO, labelled as social (Figure 9). The detected social map agreed with the annotation-based map (Spearman ρ = 0.85–0.94 across cells in four scenes; 0.55 in sparse Hotel), so it can serve as a measurement in this setting.

![](figs/fig9_flow_vs_encounter.png){width="6.5in"}

***Figure 9. Pedestrian presence versus detected social encounters in two benchmark scenes (2 m cells). Squares mark the top 10% of cells by presence; circles mark the top 10% by detected social encounter time. Right: share of co-presence episodes classified as social in cells with at least five episodes.***

Flow predicted transit co-presence almost perfectly (ρ = 0.91–0.95 in every scene) but predicted social encounters only partly (ρ = 0.42–0.77). The places with most social encounter time were often not the busiest places. In Zara01, none of the top-10% cells by social encounter time was among the top-10% cells by presence. The social hotspot lay in cells of only moderate presence, where the share of co-presence that was social reached 0.78, against at most 0.15 anywhere in the Students plaza. In Students, the busiest and most social cells overlapped by one third. Across the five scenes, overlap ranged from 0% to 67%.

For design, this means flow counts alone would misplace interventions meant to support lingering and meeting. The encounter map identifies candidate locations for seating, shade or programming: cells where social encounters already concentrate, or busy cells where the social share is low. It provides decision support, not a demonstration of design effectiveness. The analysis covers minutes of footage in five small scenes, and the maps carry the classifier's errors, including its weakness on stationary classes. Whether an intervention changes encounter patterns is a causal question for the designs discussed earlier: staggered roll-out across comparable sites analysed by difference-in-differences (Callaway & Sant'Anna, 2021), or a synthetic control when one site is treated (Abadie, 2021), with encounter time per hour of observation as the outcome and sensor coverage held constant. Maps released beyond the analysis team should carry a stated privacy budget and protected unit.

# Limitations and Open Issues

**External validity.** The benchmark covers five scenes in two cities, 1,530 pedestrians and about 41 minutes of footage. It does not span other cultures, climates, age profiles or night-time conditions, and the calibrated values should not be reused elsewhere. Stationary social classes were rare (72 episodes, 79% in one scene).

**Ground truth.** Group annotations record who walked together, not who interacted. Meetings between people who arrived separately count as Transit Crossing, and adjacent but silent companions count as social. Only companion detection is independently validated; the four-class results measure consistency with an operational taxonomy that shares variables with the classifier. Validating Brief and Sustained encounters requires longer observation and annotation of interaction itself, such as the pairwise interaction coding of van Ameijde et al. (2025).

**Simulated modalities.** Sensor effects were simulated one factor at a time and are therefore optimistic.

**Privacy and equity.** Even aggregated location data carry re-identification risk (Farzanehfar et al., 2021). The hotspot release guarantees privacy per episode, and per person only through group privacy, which is weak for highly connected people. Neither differential privacy nor federation corrects coverage bias, and the penetration experiment shows that biased coverage distorts the social share by about half. Coverage auditing is therefore a precondition for equitable recommendations.

**Interpretation.** The framework measures classified co-presence, not social ties or wellbeing. Linking encounter classes to residents' social outcomes, transferring validity across cultures and governing long-running sensor networks remain open problems.

# Conclusion

This chapter has given the urban encounter an operational definition, stated a six-class taxonomy as an explicit decision procedure, and evaluated it reproducibly on public data with human-annotated groups. The evaluation validates companion detection against annotation and four operational categories (Transit Crossing, Companionate Movement, Group Encounter and a combined stationary dyad), not the full six-class taxonomy. Brief and Sustained encounters remain untested.

Within that scope, five findings stand out. First, thresholds must be calibrated per site and sensor: literature defaults detected almost no groups, transferred camera-grade thresholds lost up to 0.16 F1, and a density-adaptive radius offers a zero-label starting point. Second, validation design changes conclusions: random cross-validation favoured flexible learners, whereas leave-one-scene-out validation favoured explicit rules for reproducing the taxonomy, an advantage that largely disappeared on annotation-only tasks. Third, the hybrid strategy gave no measurable gain and is recommended only for exploratory typology discovery. Fourth, sensing quality bounds everything downstream, with GPS-grade error making pedestrian-scale detection infeasible. Fifth, privacy and scale are manageable when the protected unit is stated: episode-level differential privacy preserved hotspot maps at small budgets, and indexed search scaled linearly to a million entities per frame.

Encounter-level outputs complement flow, density and configurational analysis. In the benchmark scenes, social encounter hotspots were often not the busiest places, which is the kind of information flow counts cannot supply. Such outputs are most useful when reported with their thresholds, validation design, uncertainty, coverage and privacy parameters, so that design decisions rest on what the data can establish.


# References

Abadie, A. (2021). Using synthetic controls: Feasibility, data requirements, and methodological aspects. *Journal of Economic Literature, 59*(2), 391–425. https://doi.org/10.1257/jel.20191450

Adhinugraha, K., Rahayu, W., Hara, T., & Taniar, D. (2021). Dealing with noise in crowdsourced GPS human trajectory logging data. *Concurrency and Computation: Practice and Experience, 33*(19), e6139. https://doi.org/10.1002/cpe.6139

Al Qathrady, M., & Helmy, A. (2017). Improving BLE distance estimation and classification using TX power and machine learning: A comparative analysis. In *Proceedings of the 20th ACM International Conference on Modelling, Analysis and Simulation of Wireless and Mobile Systems* (pp. 79–83). https://doi.org/10.1145/3127540.3127577

Alipour, B., Al Qathrady, M., & Helmy, A. (2018). On the relation between mobile encounters and web traffic patterns: A data-driven study. *arXiv*. https://doi.org/10.48550/arXiv.1808.03842

Amirian, J., Zhang, B., Castro, F. V., Baldelomar, J. J., Hayet, J.-B., & Pettré, J. (2020). OpenTraj: Assessing prediction complexity in human trajectories datasets. In *Proceedings of the Asian Conference on Computer Vision (ACCV 2020)*. Springer. https://doi.org/10.48550/arXiv.2010.00890

Bahle, G., Fortes Rey, V., Bian, S., Bello, H., & Lukowicz, P. (2021). Using privacy respecting sound analysis to improve Bluetooth based proximity detection for COVID-19 exposure tracing and social distancing. *Sensors, 21*(16), 5604. https://doi.org/10.3390/s21165604

Batty, M. (2024). *The computable city: Histories, technologies, stories, predictions*. MIT Press.

Callaway, B., & Sant'Anna, P. H. C. (2021). Difference-in-differences with multiple time periods. *Journal of Econometrics, 225*(2), 200–230. https://doi.org/10.1016/j.jeconom.2020.12.001

Chen, W., Natapov, A., & Ali, Y. (2025). Can urban vitality be seen? Video analytics of social interaction and land use. *Land Use Policy, 159*, 107818. https://doi.org/10.1016/j.landusepol.2025.107818

Ehsanpour, M., Saleh, F., Savarese, S., Reid, I., & Rezatofighi, H. (2022). JRDB-Act: A large-scale dataset for spatio-temporal action, social group and activity detection. In *Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR 2022)*. https://doi.org/10.48550/arXiv.2106.08827

Farzanehfar, A., Houssiau, F., & de Montjoye, Y.-A. (2021). The risk of re-identification remains high even in country-scale location datasets. *Patterns, 2*(3), 100204. https://doi.org/10.1016/j.patter.2021.100204

Gregorj, A., Yücel, Z., Zanlungo, F., Feliciani, C., & Kanda, T. (2023). Social aspects of collision avoidance: A detailed analysis of two-person groups and individual pedestrians. *Scientific Reports, 13*, 5756. https://doi.org/10.1038/s41598-023-32883-z

Hillier, B., & Hanson, J. (1984). *The social logic of space*. Cambridge University Press. https://doi.org/10.1017/CBO9780511597237

Huang, Q., Liu, Z., Ding, Z., Sheng, W., & Shen, J. (2026). Simulation of pedestrian grouping and avoidance behavior using an enhanced social force model. *Sustainability, 18*(2), 746. https://doi.org/10.3390/su18020746

Jahangard, S., Hayat, M., & Rezatofighi, H. (2023). Real-time trajectory-based social group detection. *arXiv*. https://doi.org/10.48550/arXiv.2304.05678

Jin, G., Liang, Y., Fang, Y., Shao, Z., Huang, J., Zhang, J., & Zheng, Y. (2023). Spatio-temporal graph neural networks for predictive learning in urban computing: A survey. *IEEE Transactions on Knowledge and Data Engineering, 36*(10), 5388–5408. https://doi.org/10.1109/TKDE.2023.3333824

Johnsson, C., & Camporeale, R. (2022). Exploring space syntax integration at public transport hubs and public squares using drone footage. *Applied Sciences, 12*(13), 6515. https://doi.org/10.3390/app12136515

Kairouz, P., McMahan, H. B., et al. (2021). Advances and open problems in federated learning. *Foundations and Trends in Machine Learning, 14*(1–2), 1–210. https://doi.org/10.1561/2200000083

Kapoor, S., & Narayanan, A. (2023). Leakage and the reproducibility crisis in machine-learning-based science. *Patterns, 4*(9), 100804. https://doi.org/10.1016/j.patter.2023.100804

Koh, Z., Zhou, Y., Lau, B. P. L., Yuen, C., Tunçer, B., & Chong, K. H. (2022). Multiple-perspective clustering of passive Wi-Fi sensing trajectory data. *IEEE Transactions on Big Data, 8*(5), 1312–1325. https://doi.org/10.1109/TBDATA.2020.3045154

Kohli, N., Aiken, E., & Blumenstock, J. E. (2024). Privacy guarantees for personal mobility data in humanitarian response. *Scientific Reports, 14*, 28565. https://doi.org/10.1038/s41598-024-79561-2

Korbmacher, R., & Tordeux, A. (2024). Toward better pedestrian trajectory predictions: The role of density and time-to-collision in hybrid deep-learning algorithms. *Sensors, 24*(7), 2356. https://doi.org/10.3390/s24072356

Leith, D. J., & Farrell, S. (2021). Measurement-based evaluation of Google/Apple Exposure Notification API for proximity detection in a commuter bus. *PLoS ONE, 16*(4), e0250826. https://doi.org/10.1371/journal.pone.0250826

Lerner, A., Chrysanthou, Y., & Lischinski, D. (2007). Crowds by example. *Computer Graphics Forum, 26*(3), 655–664. https://doi.org/10.1111/j.1467-8659.2007.01089.x

Liu, X. (2025). AI-driven real-time responsive design of urban open spaces based on multi-modal sensing data fusion. *Scientific Reports, 15*(1), 41255. https://doi.org/10.1038/s41598-025-25143-9

Luca, M., Barlacchi, G., Lepri, B., & Pappalardo, L. (2023). A survey on deep learning for human mobility. *ACM Computing Surveys, 55*(1), 1–44. https://doi.org/10.1145/3485125

Meyer, H., & Pebesma, E. (2022). Machine learning-based global maps of ecological variables and the challenge of assessing them. *Nature Communications, 13*, 2208. https://doi.org/10.1038/s41467-022-29838-9

Near, J. P., Darais, D., Lefkovitz, N., & Howarth, G. (2025). *Guidelines for evaluating differential privacy guarantees* (NIST Special Publication 800-226). National Institute of Standards and Technology. https://doi.org/10.6028/NIST.SP.800-226

Niu, T., Qing, L., Han, L., Long, Y., Hou, J., Li, L., Tang, W., & Teng, Q. (2022). Small public space vitality analysis and evaluation based on human trajectory modeling using video data. *Building and Environment, 225*, 109563. https://doi.org/10.1016/j.buildenv.2022.109563

Pandya, S., Srivastava, G., Jhaveri, R., Babu, M. R., Bhattacharya, S., Maddikunta, P. K. R., Mastorakis, S., Piran, M. J., & Gadekallu, T. R. (2023). Federated learning for smart cities: A comprehensive survey. *Sustainable Energy Technologies and Assessments, 55*, 102987. https://doi.org/10.1016/j.seta.2022.102987

Pappalardo, L., Manley, E., Sekara, V., & Alessandretti, L. (2023). Future directions in human mobility science. *Nature Computational Science, 3*, 588–600. https://doi.org/10.1038/s43588-023-00469-4

Pei, X., Yang, X., Wang, T., & Ding, Z. (2024). Travel-mode inference based on GPS-trajectory data through multi-scale mixed attention mechanism. *Heliyon, 10*(15), e35572. https://doi.org/10.1016/j.heliyon.2024.e35572

Pellegrini, S., Ess, A., Schindler, K., & Van Gool, L. (2009). You'll never walk alone: Modeling social behavior for multi-target tracking. In *Proceedings of the IEEE 12th International Conference on Computer Vision* (pp. 261–268). https://doi.org/10.1109/ICCV.2009.5459260

Piadyk, Y., Rulff, J., Brewer, E., Hosseini, M., Ozbay, K., Sankaradas, M., Chakradhar, S., & Silva, C. (2023). StreetAware: A high-resolution synchronized multimodal urban scene dataset. *Sensors, 23*(7), 3710. https://doi.org/10.3390/s23073710

Salazar-Miranda, A., Fan, Z., Baick, M., Hampton, K. N., Duarte, F., Loo, B. P. Y., Glaeser, E., & Ratti, C. (2025). Exploring the social life of urban spaces through AI. *Proceedings of the National Academy of Sciences, 122*(30), e2424662122. https://doi.org/10.1073/pnas.2424662122

Sheng, W., Shen, J., Huang, Q., Liu, Z., & Ding, Z. (2024). Multi-objective pedestrian tracking method based on YOLOv8 and improved DeepSORT. *Mathematical Biosciences and Engineering, 21*(2), 1791–1805. https://doi.org/10.3934/mbe.2024077

Stanitsa, A., Hallett, S. H., & Jude, S. (2023). Investigating pedestrian behaviour in urban environments: A Wi-Fi tracking and machine learning approach. *Multimodal Transportation, 2*(1), 100049. https://doi.org/10.1016/j.multra.2022.100049

Su, Z., Pahlavan, K., & Agu, E. (2021). Performance evaluation of COVID-19 proximity detection using Bluetooth LE signal. *IEEE Access, 9*, 38891–38906. https://doi.org/10.1109/ACCESS.2021.3064323

van Ameijde, J., Cheng, S., Leung, K. S., Zhang, W., & Dong, J. (2025). Decoding micro-social interactions in public space: A computer-vision-based method. *Computational Urban Science, 5*, 55. https://doi.org/10.1007/s43762-025-00211-y

van Nes, A., & Yamu, C. (2021). *Introduction to space syntax in urban studies*. Springer. https://doi.org/10.1007/978-3-030-59140-3

Wang, J., Feng, C.-C., & Guo, Z. (2023). A novel graph-based framework for classifying urban functional zones with multisource data and human mobility patterns. *Remote Sensing, 15*(3), 730. https://doi.org/10.3390/rs15030730

Yau, T., Malekmohammadi, S., Rasouli, A., Lakner, P., Rohani, M., & Luo, J. (2021). Graph-SIM: A graph-based spatiotemporal interaction modelling for pedestrian action prediction. In *2021 IEEE International Conference on Robotics and Automation (ICRA)* (pp. 8580–8586). IEEE. https://doi.org/10.1109/ICRA48506.2021.9561107

# Additional Reading

Bae, I., Park, J.-H., & Jeon, H.-G. (2022). Learning pedestrian group representations for multi-modal trajectory prediction. In *Computer Vision – ECCV 2022* (Lecture Notes in Computer Science, Vol. 13682). Springer. https://doi.org/10.48550/arXiv.2207.09953

Korbmacher, R., & Tordeux, A. (2022). Review of pedestrian trajectory prediction methods: Comparing deep learning and knowledge-based approaches. *IEEE Transactions on Intelligent Transportation Systems, 23*(12), 24126–24144.

# Key Terms and Definitions

**Encounter:** A spatiotemporally bounded co-presence episode between tracked entities, defined by a proximity radius, a gap tolerance and a minimum duration, with a feature vector and a class label.

**Encounter Classification:** Assignment of each detected encounter to one taxonomy class by explicit decision boundaries or a learned model, with a reject option for ambiguous cases.

**External Ground Truth:** Behavioural reference information obtained independently of proximity geometry, such as human annotation of who walks together.

**Leave-One-Site-Out Validation:** Holding out each site in turn and fitting on the others, so that performance reflects transfer to an unseen location.

**Threshold Calibration:** Estimating proximity thresholds by maximizing agreement with external ground truth on calibration sites and reporting performance on held-out sites.

**Censored Encounter:** An encounter whose start or end lies outside the observation window, so its observed duration is a lower bound.

**Differential Privacy:** A guarantee, with budget ε, that a released statistic changes little whether or not one protected unit (an episode or a person) is included.

**Federated Learning:** Training a shared model across sites that keep raw data locally and exchange only model parameters.

**Spatial Integration:** A space syntax measure of a location's relative accessibility in a street network, used as a structural baseline for encounter densities.
