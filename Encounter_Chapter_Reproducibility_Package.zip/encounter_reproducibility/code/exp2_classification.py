"""Experiment 2: taxonomy classification with rule-based, supervised, unsupervised and
hybrid strategies; random vs temporal-block vs leave-one-scene-out validation;
bootstrap CIs, paired tests, ablation, reject option, label-budget curves."""
import numpy as np, pandas as pd, json, itertools, warnings, time
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingClassifier
from sklearn.mixture import GaussianMixture
from sklearn.cluster import KMeans
from sklearn.metrics import f1_score, confusion_matrix, precision_recall_fscore_support, \
    adjusted_rand_score, normalized_mutual_info_score, silhouette_score
from sklearn.model_selection import StratifiedKFold
from statsmodels.stats.contingency_tables import mcnemar
import encounter_lib as L

warnings.filterwarnings("ignore")
E = pd.read_csv("../results/episodes_clean.csv")
FEATS = L.ALL_FEATURES
CL = L.CLASSES
E["y"] = E.ref.map({c: i for i, c in enumerate(CL)})
E["pair"] = E.scene + ":" + E.a.astype(str) + "-" + E.b.astype(str)
SCN = list(L.SCENES)
SEED = 0


def macro(y, p):
    return f1_score(y, p, labels=range(4), average="macro", zero_division=0)


def binf1(y, p):
    return f1_score((y > 0).astype(int), (p > 0).astype(int), zero_division=0)


# ------------------------------------------------------------------ models
def rf(seed=SEED, **kw):
    params = dict(n_estimators=500, min_samples_leaf=2, max_features="sqrt",
                  class_weight="balanced_subsample", n_jobs=2, random_state=seed)
    params.update(kw)
    return RandomForestClassifier(**params)


def lr():
    return make_pipeline(StandardScaler(), LogisticRegression(C=1.0, max_iter=3000,
                                                             class_weight="balanced"))


def hgb(seed=SEED):
    return HistGradientBoostingClassifier(max_iter=300, learning_rate=0.05, max_leaf_nodes=15,
                                          class_weight="balanced", random_state=seed)


class RuleBased:
    """Explicit decision boundaries (Eq. 4-7 in the chapter); thresholds grid-searched
    on training scenes for macro-F1."""
    GRID = dict(td=[0.75, 1.0, 1.25, 1.5, 2.0], tt=[2.0, 4.0, 6.0, 8.0],
                tc=[-1.0, 0.5, 0.8, 0.9], tv=[0.3, 0.5, 1.0, 99])

    def _pred(self, X, td, tt, tc, tv):
        social = (X.d_mean <= td) & (X.dur >= tt) & (X.dspeed <= tv) & \
                 ((X.cos_head >= tc) | (X.stat_frac >= 0.5))
        moving = X.mspeed >= L.V_STAT
        p = np.zeros(len(X), int)
        p[social & moving] = 1
        p[social & ~moving & (X.n_third == 0)] = 2
        p[social & ~moving & (X.n_third >= 1)] = 3
        return p

    def fit(self, X, y):
        best = -1
        for td, tt, tc, tv in itertools.product(*self.GRID.values()):
            s = macro(y, self._pred(X, td, tt, tc, tv))
            if s > best:
                best, self.th = s, (td, tt, tc, tv)
        return self

    def predict(self, X):
        return self._pred(X, *self.th)


class GMMMapped:
    """Unsupervised GMM (K by BIC); components mapped to classes by labelled majority."""

    def __init__(self, kmax=12, seed=SEED):
        self.kmax, self.seed = kmax, seed

    def fit(self, X, y, Xunl=None):
        Xall = X if Xunl is None else np.vstack([X, Xunl])
        self.sc = StandardScaler().fit(Xall)
        Z = self.sc.transform(Xall)
        bics = []
        for k in range(2, self.kmax + 1):
            g = GaussianMixture(k, covariance_type="full", random_state=self.seed, reg_covar=1e-3).fit(Z)
            bics.append((g.bic(Z), k, g))
        _, self.k, self.g = min(bics, key=lambda t: t[0])
        comp = self.g.predict(self.sc.transform(X))
        w = len(y) / (4 * np.maximum(np.bincount(y, minlength=4), 1))   # class-balanced vote
        self.map = {}
        for c in range(self.k):
            m = comp == c
            self.map[c] = int(np.argmax(np.bincount(y[m], weights=w[y[m]], minlength=4))) if m.any() else 0
        return self

    def posterior(self, X):
        return self.g.predict_proba(self.sc.transform(X))

    def predict(self, X):
        return np.array([self.map[c] for c in self.g.predict(self.sc.transform(X))])


class Hybrid:
    """Cluster-then-classify: GMM discovered on all (incl. unlabelled) training episodes;
    confident unlabelled episodes pseudo-labelled via component->class map; RF trained
    on labelled + pseudo-labelled data with GMM posteriors appended as features."""

    def __init__(self, seed=SEED, tau=0.9):
        self.seed, self.tau = seed, tau

    def fit(self, X, y, Xunl=None):
        self.gm = GMMMapped(seed=self.seed).fit(X, y, Xunl)
        Xs, ys = X, y
        if Xunl is not None and len(Xunl):
            P = self.gm.posterior(Xunl)
            conf = P.max(1) >= self.tau
            yp = np.array([self.gm.map[c] for c in P.argmax(1)])
            Xs = np.vstack([X, Xunl[conf]]); ys = np.concatenate([y, yp[conf]])
        self.rf = rf(self.seed).fit(np.hstack([Xs, self.gm.posterior(Xs)]), ys)
        return self

    def predict_proba(self, X):
        return self.rf.predict_proba(np.hstack([X, self.gm.posterior(X)]))

    def predict(self, X):
        return self.rf.classes_[self.predict_proba(X).argmax(1)]


def fit_predict(name, Xtr, ytr, Xte, seed=SEED, Xunl=None, feats=FEATS):
    if name == "Rule-based":
        m = RuleBased().fit(Xtr, ytr); return m.predict(Xte)
    A, B = Xtr[feats].values, Xte[feats].values
    if name == "Logistic regression":
        return lr().fit(A, ytr).predict(B)
    if name == "Random forest":
        return rf(seed).fit(A, ytr).predict(B)
    if name == "Gradient boosting":
        return hgb(seed).fit(A, ytr).predict(B)
    if name == "Unsupervised GMM":
        return GMMMapped(seed=seed).fit(A, ytr, None if Xunl is None else Xunl[feats].values).predict(B)
    if name == "Hybrid":
        return Hybrid(seed).fit(A, ytr, None if Xunl is None else Xunl[feats].values).predict(B)
    raise ValueError(name)


METHODS = ["Rule-based", "Logistic regression", "Random forest", "Gradient boosting",
           "Unsupervised GMM", "Hybrid"]


# ------------------------------------------------------------------ CV schemes
def folds(scheme):
    if scheme == "LOSO":
        for s in SCN:
            yield (E.scene != s).values, (E.scene == s).values
    elif scheme == "Random 5-fold":
        skf = StratifiedKFold(5, shuffle=True, random_state=SEED)
        for tr, te in skf.split(E, E.y):
            a = np.zeros(len(E), bool); a[tr] = True; yield a, ~a
    elif scheme == "Temporal block":
        # 5 contiguous time blocks per scene; fold k tests block k of every scene
        blk = E.groupby("scene").t0.transform(lambda t: pd.qcut(t.rank(method="first"), 5, labels=False))
        for k in range(5):
            # 1-block buffer either side removed from training to limit temporal leakage
            te = (blk == k).values
            tr = (np.abs(blk - k) > 1).values
            yield tr, te


def cluster_boot(df_pred, metric, B=2000, rng=np.random.default_rng(11)):
    """Bootstrap over pedestrian pairs (cluster bootstrap) -> 95% CI."""
    pairs = df_pred.pair.values
    up, inv = np.unique(pairs, return_inverse=True)
    idx_by = [np.flatnonzero(inv == i) for i in range(len(up))]
    vals = []
    for _ in range(B):
        pick = rng.integers(0, len(up), len(up))
        ii = np.concatenate([idx_by[i] for i in pick])
        vals.append(metric(df_pred.y.values[ii], df_pred.p.values[ii]))
    return np.percentile(vals, [2.5, 97.5]), np.array(vals)


def paired_boot_diff(y, p1, p2, pairs, metric, B=2000, rng=np.random.default_rng(13)):
    up, inv = np.unique(pairs, return_inverse=True)
    idx_by = [np.flatnonzero(inv == i) for i in range(len(up))]
    d = []
    for _ in range(B):
        pick = rng.integers(0, len(up), len(up))
        ii = np.concatenate([idx_by[i] for i in pick])
        d.append(metric(y[ii], p1[ii]) - metric(y[ii], p2[ii]))
    d = np.array(d)
    return d.mean(), np.percentile(d, [2.5, 97.5]), 2 * min((d <= 0).mean(), (d >= 0).mean())


if __name__ == "__main__":
    t0 = time.time()
    out = {}
    # ---------------- A. methods x CV schemes
    rows = []; preds = {}
    for scheme in ["Random 5-fold", "Temporal block", "LOSO"]:
        for mname in METHODS:
            p = np.full(len(E), -1)
            for tr, te in folds(scheme):
                p[te] = fit_predict(mname, E[tr], E.y.values[tr], E[te])
            m = p >= 0
            dfp = pd.DataFrame(dict(y=E.y.values[m], p=p[m], pair=E.pair.values[m]))
            preds[(scheme, mname)] = p
            ci, _ = cluster_boot(dfp, macro, B=1000)
            cib, _ = cluster_boot(dfp, binf1, B=1000)
            rows.append(dict(scheme=scheme, method=mname, macroF1=macro(dfp.y, dfp.p),
                             ci_lo=ci[0], ci_hi=ci[1], socialF1=binf1(dfp.y, dfp.p),
                             s_ci_lo=cib[0], s_ci_hi=cib[1]))
            print(rows[-1], round(time.time() - t0), flush=True)
    A = pd.DataFrame(rows); A.to_csv("../results/exp2_methods_cv.csv", index=False)
    np.save("../results/exp2_preds.npy", {f"{k[0]}|{k[1]}": v for k, v in preds.items()})

    # per-scene LOSO macro-F1 for each method
    ps = []
    for mname in METHODS:
        p = preds[("LOSO", mname)]
        for s in SCN:
            m = (E.scene == s).values
            ps.append(dict(method=mname, scene=s, macroF1=macro(E.y.values[m], p[m]),
                           socialF1=binf1(E.y.values[m], p[m])))
    pd.DataFrame(ps).to_csv("../results/exp2_loso_by_scene.csv", index=False)

    # ---------------- B. paired significance (LOSO): Hybrid vs others
    y = E.y.values; pairs = E.pair.values
    sig = []
    for ref in ["Hybrid", "Random forest"]:
        for other in METHODS:
            if other == ref:
                continue
            p1, p2 = preds[("LOSO", ref)], preds[("LOSO", other)]
            md, ci, pv = paired_boot_diff(y, p1, p2, pairs, macro)
            c1, c2 = p1 == y, p2 == y
            tab = [[np.sum(c1 & c2), np.sum(c1 & ~c2)], [np.sum(~c1 & c2), np.sum(~c1 & ~c2)]]
            mc = mcnemar(tab, exact=False, correction=True)
            sig.append(dict(ref=ref, vs=other, dMacroF1=md, ci_lo=ci[0], ci_hi=ci[1], p_boot=pv,
                            mcnemar_chi2=mc.statistic, mcnemar_p=mc.pvalue))
    pd.DataFrame(sig).to_csv("../results/exp2_significance.csv", index=False)
    print(pd.DataFrame(sig).round(4))

    # ---------------- C. per-class report + confusion matrix (LOSO, RF and Hybrid)
    for mname in ["Random forest", "Hybrid", "Rule-based"]:
        p = preds[("LOSO", mname)]
        pr, rc, f1, sup = precision_recall_fscore_support(y, p, labels=range(4), zero_division=0)
        cm = confusion_matrix(y, p, labels=range(4))
        out[mname] = dict(precision=pr.tolist(), recall=rc.tolist(), f1=f1.tolist(),
                          support=sup.tolist(), cm=cm.tolist())
    json.dump(out, open("../results/exp2_perclass.json", "w"), indent=1)
    print(json.dumps(out, indent=0)[:1500])
    print("total", round(time.time() - t0))
