"""Experiment 4c: BLE shadowing with repeated random seeds (variability of the simulation).
For each shadowing level and seed, LOSO-calibrated (d_s, t_min) threshold detector."""
import numpy as np, pandas as pd, time
import encounter_lib as L
import exp1_thresholds as X1

rows = []; t0 = time.time()
orig = X1.ble_distance
for sdb in [2, 4, 6, 8, 10]:
    for seed in range(3):
        X1.ble_distance = lambda d, rng, s=sdb: orig(d, rng, sigma_db=s)
        rng = np.random.default_rng(1000 + seed)
        tabs = {s: X1.pair_table(s, "BLE", rng=rng)[:2] for s in L.SCENES}
        grids = {s: X1.f1_grid(*tabs[s])[0] for s in L.SCENES}
        f1s, dss = [], []
        for s in L.SCENES:
            other = np.mean([grids[o] for o in L.SCENES if o != s], axis=0)
            i, j = np.unravel_index(np.argmax(other), other.shape)
            f1s.append(X1.f1_at(*tabs[s], X1.DS_GRID[i], X1.T_GRID[j])[0]); dss.append(X1.DS_GRID[i])
        rows.append(dict(sigma_db=sdb, seed=1000 + seed, mean_loso_f1=np.mean(f1s), median_ds=np.median(dss)))
        print(rows[-1], round(time.time() - t0), flush=True)
X1.ble_distance = orig
R = pd.DataFrame(rows); R.to_csv("../results/exp4c_ble_seeds.csv", index=False)
print(R.groupby("sigma_db").mean_loso_f1.agg(["mean", "std", "min", "max"]).round(3))
