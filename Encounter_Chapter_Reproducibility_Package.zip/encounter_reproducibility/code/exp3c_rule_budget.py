"""Experiment 3c: rule-based calibration with the same label budgets and seeds as exp3."""
import numpy as np, pandas as pd, warnings
from exp2_classification import E, SCN, macro, binf1, RuleBased

warnings.filterwarnings("ignore")
y = E.y.values; rows = []
for frac in [0.01, 0.02, 0.05, 0.10, 0.25, 0.50, 1.0]:
    for seed in range(5):
        rng = np.random.default_rng(seed); p = np.zeros(len(E), int)
        for s in SCN:
            tr_idx = np.flatnonzero((E.scene != s).values); te = (E.scene == s).values
            n_lab = max(int(frac * len(tr_idx)), 8)
            lab = set(rng.choice(tr_idx, n_lab, replace=False))
            for c in range(4):
                ci = tr_idx[y[tr_idx] == c]
                if len(ci):
                    lab |= set(rng.choice(ci, min(2, len(ci)), replace=False))
            lab = np.array(sorted(lab))
            m = RuleBased().fit(E.iloc[lab], y[lab]); p[te] = m.predict(E[te])
        rows.append(dict(frac=frac, seed=seed, method="Rule-based", macroF1=macro(y, p), socialF1=binf1(y, p)))
        print(rows[-1], flush=True)
        if frac == 1.0:
            break
pd.DataFrame(rows).to_csv("../results/exp3c_rule_budget.csv", index=False)
