"""Figure 9: flow versus detected social encounters (real spatial analysis)."""
import numpy as np, pandas as pd
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from figs_common import *

maps = np.load("/home/claude/work/results/exp7_maps.npy", allow_pickle=True).item()
SP = pd.read_csv("/home/claude/work/results/exp7_spatial.csv").set_index("scene")
cmap = LinearSegmentedColormap.from_list("seq", ["#fcfcfb"] + SEQ)
cmap2 = LinearSegmentedColormap.from_list("seq2", ["#fcfcfb", "#fbd9c9", "#f4a27c", "#eb6834", "#b8461b"])
scenes = ["Zara01", "Students"]
fig, axs = plt.subplots(2, 3, figsize=(6.8, 5.0))
fig.subplots_adjust(hspace=0.45, wspace=0.32)
for r, s in enumerate(scenes):
    m = maps[s]; ext = [m["x0"], m["x0"] + 2 * m["F"].shape[0], m["y0"], m["y0"] + 2 * m["F"].shape[1]]
    F, S, sh = m["F"], m["S"], m["share"]
    k = max(1, int(0.1 * (F > 0).sum()))
    topF = np.argsort(-F.ravel())[:k]; topS = np.argsort(-S.ravel())[:k]
    for c, (Z, cm, title, lab) in enumerate([(F / 60, cmap, "Pedestrian presence", "person-min per cell"),
                                             (S / 60, cmap2, "Detected social encounters", "encounter-min per cell"),
                                             (sh, cmap2, "Social share of co-presence", "share (cells ≥5 episodes)")]):
        a = axs[r, c]
        im = a.imshow(Z.T, origin="lower", extent=ext, cmap=cm, aspect="equal",
                      vmin=0, vmax=None if c < 2 else np.nanmax(sh))
        a.grid(False); a.set_xticks([]); a.set_yticks([])
        a.set_title(f"{s}: {title}" if c == 0 else title, loc="left", fontsize=8)
        cb = fig.colorbar(im, ax=a, shrink=0.75, pad=0.03); cb.ax.tick_params(labelsize=6.5)
        cb.set_label(lab, fontsize=6.5)
        nx = F.shape[1]
        if c < 2:
            for idx, col, mk in [(topF, INK, "s"), (topS, S2, "o")] if c == 1 else [(topF, INK, "s")]:
                ii, jj = np.unravel_index(idx, F.shape)
                a.scatter(m["x0"] + 2 * ii + 1, m["y0"] + 2 * jj + 1, s=22, facecolor="none", edgecolor=col,
                          lw=1.0, marker=mk)
    axs[r, 1].text(0.02, -0.12, f"ρ(flow, social) = {SP.loc[s, 'rho_flow_social']:.2f};  top-10% overlap "
                   f"{SP.loc[s, 'top10pct_overlap_flow_social']:.0%}", transform=axs[r, 1].transAxes, fontsize=7, color=INK2)
fig.text(0.01, 0.005, "□ top 10% cells by pedestrian presence   ○ top 10% cells by detected social encounter time   (2 m cells)",
         fontsize=7, color=INK2)
save(fig, "fig9_flow_vs_encounter")
print("ok")
