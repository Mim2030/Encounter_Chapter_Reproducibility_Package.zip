"""Experiment 7: analyses requested in the pre-submission review.
(a) circularity check: annotation-only labels (no kinematic construction)
(b) agreement of kinematic sub-classes among correctly detected social episodes
(c) reconciliation of social episodes vs annotated pairs
(d) zero-label density-adaptive thresholds (transfer with no target labels)
(e) differential privacy re-analysis with an explicit protected unit
(f) spatial analysis: pedestrian flow vs detected social encounters"""
import numpy as np, pandas as pd, json, itertools, warnings
from scipy.stats import spearmanr
from sklearn.metrics import f1_score
import encounter_lib as L
import exp1_thresholds as X1
from exp2_classification import E, SCN, macro, binf1, rf, RuleBased, cluster_boot, paired_boot_diff

warnings.filterwarnings("ignore")
OUT = {}
y = E.y.values; pairs = E.pair.values
preds = np.load("../results/exp2_preds.npy", allow_pickle=True).item()
p_rule, p_rf = preds["LOSO|Rule-based"], preds["LOSO|Random forest"]

# ---------------- (a) annotation-only three-class task
gsize = {}
for s in SCN:
    _, groups = L.load_scene(s)
    for g in groups:
        for p in g:
            gsize[(s, p)] = len(g)
E["gsize"] = [gsize.get((s, a), 1) for s, a in zip(E.scene, E.a)]
yA = np.where(E.social == 0, 0, np.where(E.gsize >= 3, 2, 1))
OUT["annot_task_counts"] = dict(zip(["Transit", "Pair (group of 2)", "Larger group (3+)"],
                                    np.bincount(yA).tolist()))


def m3(a, b):
    return f1_score(a, b, labels=[0, 1, 2], average="macro", zero_division=0)


class Rule3(RuleBased):
    def _pred(self, X, td, tt, tc, tv):
        social = (X.d_mean <= td) & (X.dur >= tt) & (X.dspeed <= tv) & ((X.cos_head >= tc) | (X.stat_frac >= 0.5))
        p = np.zeros(len(X), int); p[social & (X.n_third == 0)] = 1; p[social & (X.n_third >= 1)] = 2
        return p

    def fit(self, X, yy):
        best = -1
        for th in itertools.product(*self.GRID.values()):
            sc = m3(yy, self._pred(X, *th))
            if sc > best:
                best, self.th = sc, th
        return self


pa_rule = np.zeros(len(E), int); pa_rf = np.zeros(len(E), int)
for s in SCN:
    tr = (E.scene != s).values
    pa_rule[~tr] = Rule3().fit(E[tr], yA[tr]).predict(E[~tr])
    pa_rf[~tr] = rf(0).fit(E.loc[tr, L.ALL_FEATURES].values, yA[tr]).predict(E.loc[~tr, L.ALL_FEATURES].values)
res = {}
for nm, p in [("Rule-based", pa_rule), ("Random forest", pa_rf)]:
    d = pd.DataFrame(dict(y=yA, p=p, pair=pairs))
    ci, _ = cluster_boot(d, m3, B=1000)
    cs, _ = cluster_boot(d, lambda a, b: f1_score(a > 0, b > 0, zero_division=0), B=1000)
    pc = f1_score(yA, p, labels=[0, 1, 2], average=None, zero_division=0)
    res[nm] = dict(macroF1=m3(yA, p), ci=ci.tolist(), socialF1=f1_score(yA > 0, p > 0), sci=cs.tolist(),
                   per_class=pc.tolist())
md, mci, mp = paired_boot_diff(yA, pa_rule, pa_rf, pairs, m3, B=2000)
res["diff_rule_minus_rf"] = dict(point=m3(yA, pa_rule) - m3(yA, pa_rf), ci=mci.tolist(), p=mp)
OUT["annotation_only_task"] = res
# paired test on the externally grounded binary task with the original 4-class predictions
sd, sci_, sp = paired_boot_diff(y, p_rule, p_rf, pairs, binf1, B=2000)
OUT["social_f1_rule_minus_rf"] = dict(point=binf1(y, p_rule) - binf1(y, p_rf), ci=sci_.tolist(), p=sp)

# ---------------- (b) kinematic sub-class agreement among correctly detected social episodes
sub = {}
for nm, p in [("Rule-based", p_rule), ("Random forest", p_rf)]:
    m = (y > 0) & (p > 0)
    mov_ok = np.mean((y[m] == 1) == (p[m] == 1))
    st = m & (y >= 2) & (p >= 2)
    sub[nm] = dict(n_correct_social=int(m.sum()), moving_vs_stationary_agreement=float(mov_ok),
                   dyad_vs_group_agreement=float(np.mean(y[st] == p[st])) if st.any() else None, n_stat=int(st.sum()))
OUT["kinematic_subclass_agreement"] = sub
# how well does n_third (any third party) reproduce annotated group size among stationary social episodes?
stat_soc = (E.social == 1) & (E.mspeed < L.V_STAT)
OUT["nthird_vs_annotated_size"] = dict(
    n=int(stat_soc.sum()),
    agreement=float(np.mean((E.n_third[stat_soc] >= 1) == (E.gsize[stat_soc] >= 3))),
    agreement_with_reference_group_label=float(np.mean((E.n_third[stat_soc] >= 1) == (E.ref[stat_soc] == "Group"))))

# ---------------- (c) social episodes vs annotated pairs
meta = pd.read_csv("../results/exp1_meta.csv"); meta = meta[meta.modality == "Truth"]
soc = E[E.social == 1].groupby(["scene", "a", "b"]).size()
OUT["episodes_vs_pairs"] = dict(annotated_pairs_coobserved=int(meta.n_pos.sum()), pairs_with_episode=int(len(soc)),
                                pairs_with_multiple=int((soc > 1).sum()), social_episodes=int(soc.sum()),
                                pairs_without_episode=int(meta.n_pos.sum() - len(soc)))

# ---------------- (d) zero-label transfer: fixed vs density-adaptive spatial threshold
tabs = np.load("../results/exp1_tables.npy", allow_pickle=True).item()
nn = dict(zip(meta.scene, meta.median_nn))
kap = np.round(np.arange(0.5, 3.01, 0.1), 2)


def f1_adapt(s, k, ti):
    yy, M = tabs[f"Truth|{s}"]
    ds = min(max(k * nn[s], X1.DS_GRID[0]), X1.DS_GRID[-1])
    i = int(np.argmin(np.abs(X1.DS_GRID - ds)))
    return X1.f1_at(yy, M, X1.DS_GRID[i], X1.T_GRID[ti])[0]


za = []
for s in SCN:
    others = [o for o in SCN if o != s]
    best = max(((np.mean([f1_adapt(o, k, ti) for o in others]), k, ti) for k in kap for ti in range(len(X1.T_GRID))))
    za.append(dict(scene=s, kappa=best[1], t=X1.T_GRID[best[2]], f1=f1_adapt(s, best[1], best[2])))
ZA = pd.DataFrame(za); T1 = pd.read_csv("../results/exp1_thresholds.csv"); T1 = T1[T1.modality == "Truth"]
ZA["fixed_loso_f1"] = T1.set_index("scene").loc[ZA.scene, "loso_f1"].values
ZA["oracle_f1"] = T1.set_index("scene").loc[ZA.scene, "oracle_f1"].values
ZA.to_csv("../results/exp7_zero_label.csv", index=False)
OUT["zero_label"] = ZA.round(3).to_dict("records")

# ---------------- (e) DP: event-level mechanism + group privacy, explicit degree distribution
rng = np.random.default_rng(0); dp = []; deg_rows = []
for s in SCN:
    Es = E[E.scene == s]
    deg = pd.concat([Es.a, Es.b]).value_counts()
    deg_rows.append(dict(scene=s, persons=len(deg), median=float(deg.median()), p95=float(deg.quantile(.95)), max=int(deg.max())))
    x0, y0 = Es.cx.min(), Es.cy.min()
    ix = ((Es.cx - x0) // 2).astype(int); iy = ((Es.cy - y0) // 2).astype(int)
    T = np.zeros((ix.max() + 1, iy.max() + 1)); np.add.at(T, (ix, iy), 1); T = T.ravel()
    top = set(np.argsort(-T)[:10])
    for eps in [0.1, 0.25, 0.5, 1, 2, 5]:
        rec, rho = [], []
        for _ in range(300):
            N = T + rng.laplace(0, 1 / eps, T.shape)
            rec.append(len(top & set(np.argsort(-N)[:10])) / 10); rho.append(spearmanr(T, N).statistic)
        dp.append(dict(scene=s, eps_event=eps, top10_recall=np.mean(rec), spearman=np.mean(rho)))
DPd = pd.DataFrame(dp); DEG = pd.DataFrame(deg_rows)
DPd.to_csv("../results/exp7_dp_event.csv", index=False); DEG.to_csv("../results/exp7_degree.csv", index=False)
allx = pd.concat([E.a.astype(str) + E.scene, E.b.astype(str) + E.scene]).value_counts()
OUT["degree_pooled"] = dict(median=float(allx.median()), p95=float(allx.quantile(.95)), max=int(allx.max()))
OUT["dp_event_pooled"] = DPd.groupby("eps_event")[["top10_recall", "spearman"]].mean().round(3).reset_index().to_dict("records")
OUT["degree_by_scene"] = DEG.to_dict("records")

# ---------------- (f) spatial analysis: flow vs detected social encounters (2 m cells)
sp = []; maps = {}
for s in SCN:
    df, _ = L.load_scene(s)
    m = (E.scene == s).values; Es = E[m]
    x0, y0 = df.x.min(), df.y.min()
    nx, ny = int((df.x.max() - x0) // 2) + 1, int((df.y.max() - y0) // 2) + 1
    F = np.zeros((nx, ny)); np.add.at(F, (((df.x - x0) // 2).astype(int), ((df.y - y0) // 2).astype(int)), L.DT)
    def emap(mask, w):
        M_ = np.zeros((nx, ny))
        np.add.at(M_, (((Es.cx[mask] - x0) // 2).astype(int).clip(0, nx - 1),
                       ((Es.cy[mask] - y0) // 2).astype(int).clip(0, ny - 1)), w[mask])
        return M_
    ones = np.ones(len(Es)); dur = Es.dur.values
    det = (p_rule[m] > 0); ref = (Es.social.values == 1)
    Sdet = emap(det, dur); Sref = emap(ref, dur); Call = emap(np.ones(len(Es), bool), ones)
    Tr = emap(~det, ones)
    v = F.ravel() > 0
    k = max(1, int(0.1 * v.sum()))
    topF = set(np.argsort(-F.ravel())[:k]); topS = set(np.argsort(-Sdet.ravel())[:k])
    share = np.divide(emap(det, ones), Call, out=np.full_like(Call, np.nan), where=Call >= 5)
    sp.append(dict(scene=s, cells_used=int(v.sum()),
                   rho_flow_social=spearmanr(F.ravel()[v], Sdet.ravel()[v]).statistic,
                   rho_flow_transit=spearmanr(F.ravel()[v], Tr.ravel()[v]).statistic,
                   rho_detected_vs_reference_social=spearmanr(Sdet.ravel()[v], Sref.ravel()[v]).statistic,
                   top10pct_overlap_flow_social=len(topF & topS) / k,
                   social_share_range=f"{np.nanmin(share):.2f}-{np.nanmax(share):.2f}" if np.isfinite(share).any() else ""))
    maps[s] = dict(F=F, S=Sdet, R=Sref, share=share, x0=x0, y0=y0)
SP = pd.DataFrame(sp); SP.to_csv("../results/exp7_spatial.csv", index=False)
np.save("../results/exp7_maps.npy", maps, allow_pickle=True)
OUT["spatial"] = SP.round(3).to_dict("records")
json.dump(OUT, open("../results/exp7_review.json", "w"), indent=1, default=float)
print(json.dumps(OUT, indent=1, default=float))
