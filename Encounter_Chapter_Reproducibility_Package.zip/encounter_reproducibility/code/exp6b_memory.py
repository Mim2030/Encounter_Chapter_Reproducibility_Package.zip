"""Experiment 6b: peak resident memory (ru_maxrss) of each pair-search method, measured in a
fresh child process per (method, N) so that C/C++ allocations are counted."""
import subprocess, sys, json, pandas as pd

CHILD = r'''
import resource, numpy as np, sys
sys.path.insert(0, "/home/claude/work/code")
from exp6_scalability import brute, kdtree, grid_hash, DENS, R
m, N = sys.argv[1], int(sys.argv[2])
rng = np.random.default_rng(0); P = rng.random((N, 2)) * np.sqrt(N / DENS)
base = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
{"Brute force": brute, "k-d tree": kdtree, "Grid hash": grid_hash}[m](P, R)
peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
print((peak - base) / 1024)
'''
rows = []
for m, Ns in [("Brute force", [1000, 3000, 10000, 30000]), ("k-d tree", [1000, 10000, 100000, 1000000]),
              ("Grid hash", [1000, 10000, 100000, 300000])]:
    for N in Ns:
        out = subprocess.run([sys.executable, "-c", CHILD, m, str(N)], capture_output=True, text=True)
        mb = float(out.stdout.strip().splitlines()[-1])
        rows.append(dict(method=m, N=N, peak_rss_increase_MB=mb)); print(rows[-1], flush=True)
pd.DataFrame(rows).to_csv("../results/exp6_memory_rss.csv", index=False)
