"""Encounter detection & feature extraction on ETH/UCY trajectories.

Reproducible pipeline used for the revised chapter. All positions are in metres,
time step dt = 0.4 s (native annotation rate of ETH/UCY).
"""
import numpy as np
import pandas as pd
from itertools import combinations
from scipy.spatial import cKDTree

DATA_ROOT = "/home/claude/data/OpenTraj/datasets"
SCENES = {  # name: (path, frame step, city)
    "ETH": ("ETH/seq_eth", 6, "Zurich"),
    "Hotel": ("ETH/seq_hotel", 10, "Zurich"),
    "Zara01": ("UCY/zara01", 10, "Nicosia"),
    "Zara02": ("UCY/zara02", 10, "Nicosia"),
    "Students": ("UCY/students03", 10, "Nicosia"),
}
DT = 0.4
D_CAND = 3.0          # candidate co-presence radius (m) used to open an episode
GAP_TOL = 2           # frames (0.8 s) gap tolerance inside an episode
MIN_LEN = 3           # min frames (1.2 s) so velocity can be estimated
V_STAT = 0.5          # m/s: stationary vs moving reference boundary
ENV_R = 5.0           # radius for environmental density / context


def load_scene(name):
    path, step, _ = SCENES[name]
    d = np.loadtxt(f"{DATA_ROOT}/{path}/obsmat.txt")
    df = pd.DataFrame({"t": np.floor(d[:, 0] / step).astype(int), "pid": d[:, 1].astype(int),
                       "x": d[:, 2], "y": d[:, 4]})
    df["t"] -= df.t.min()
    groups = []
    with open(f"{DATA_ROOT}/{path}/groups.txt") as fh:
        for line in fh:
            ids = [int(float(v)) for v in line.split()]
            if len(ids) >= 2:
                groups.append(ids)
    return df.sort_values(["pid", "t"]).reset_index(drop=True), groups


def group_lookup(groups):
    g_of = {}
    for gi, g in enumerate(groups):
        for p in g:
            g_of[p] = gi
    return g_of


def tracks_from_df(df, dt=None, smooth=False):
    """dict pid -> (t array, xy array, v array). Velocity by central differences;
    optional Savitzky-Golay smoothing (window 7, order 2) for noisy modalities."""
    from scipy.signal import savgol_filter
    dt = DT if dt is None else dt
    tr = {}
    for pid, g in df.groupby("pid"):
        t = g.t.values
        xy = g[["x", "y"]].values.astype(float)
        if smooth and len(t) >= 7:
            xy = savgol_filter(xy, 7, 2, axis=0)
        if len(t) >= 2:
            v = np.gradient(xy, t * dt, axis=0)
        else:
            v = np.zeros_like(xy)
        tr[pid] = (t, xy, v)
    return tr


class _F:
    __slots__ = ("pid", "x", "y", "vx", "vy", "xy")


def frame_index(tr):
    """t -> lightweight record of numpy arrays (pid, x, y, vx, vy, xy)."""
    T = np.concatenate([v[0] for v in tr.values()])
    P = np.concatenate([np.full(len(v[0]), k) for k, v in tr.items()])
    XY = np.vstack([v[1] for v in tr.values()])
    V = np.vstack([v[2] for v in tr.values()])
    order = np.argsort(T, kind="stable")
    T, P, XY, V = T[order], P[order], XY[order], V[order]
    cuts = np.flatnonzero(np.diff(T)) + 1
    out = {}
    for sl in np.split(np.arange(len(T)), cuts):
        f = _F(); f.pid = P[sl]; f.xy = XY[sl]; f.x = XY[sl, 0]; f.y = XY[sl, 1]
        f.vx = V[sl, 0]; f.vy = V[sl, 1]
        out[int(T[sl[0]])] = f
    return out


def runs(mask, gap_tol=GAP_TOL, times=None):
    """Inclusive index runs of True, merging gaps <= gap_tol frames (measured on
    `times` when given, so missing frames count as gaps)."""
    idx = np.flatnonzero(mask)
    if len(idx) == 0:
        return []
    tt = np.arange(len(mask)) if times is None else np.asarray(times)
    out = []
    s = idx[0]; p = idx[0]
    for i in idx[1:]:
        if tt[i] - tt[p] - 1 <= gap_tol:
            p = i
            continue
        out.append((s, p)); s = i; p = i
    out.append((s, p))
    return out


def pair_series(tr, a, b):
    ta, xa, va = tr[a]; tb, xb, vb = tr[b]
    common, ia, ib = np.intersect1d(ta, tb, return_indices=True)
    if len(common) == 0:
        return None
    return common, xa[ia], xb[ib], va[ia], vb[ib]


def candidate_pairs(tr, radius=D_CAND):
    """Pairs that are ever within `radius` in the same frame (kd-tree per frame)."""
    fi = frame_index(tr)
    pairs = set()
    for t, g in fi.items():
        if len(g.pid) < 2:
            continue
        tree = cKDTree(g.xy)
        pids = g.pid
        for i, j in tree.query_pairs(radius):
            a, b = sorted((pids[i], pids[j]))
            pairs.add((a, b))
    return sorted(pairs), fi


def extract_episodes(tr, groups, scene, radius=D_CAND, gap_tol=GAP_TOL, min_len=MIN_LEN, fi=None,
                     pairs=None, dt=None, tr_ref=None, orig=None, t_scale=1):
    """tr_ref/orig/t_scale: when `tr` is a perturbed copy, reference labels are computed
    from the clean tracks `tr_ref`; orig(pid) maps a (possibly switched) ID to the
    annotated identity and t_scale maps perturbed time indices to clean ones."""
    dt = DT if dt is None else dt
    orig = (lambda p: p) if orig is None else orig
    g_of = group_lookup(groups)
    if pairs is None:
        pairs, fi = candidate_pairs(tr, radius)
    # occupancy prior for context: 1 m grid of all positions in the scene
    allxy = np.vstack([v[1] for v in tr.values()])
    x0, y0 = allxy.min(0)
    H, xe, ye = np.histogram2d(allxy[:, 0], allxy[:, 1],
                               bins=[np.arange(x0, allxy[:, 0].max() + 1.01, 1.0),
                                     np.arange(y0, allxy[:, 1].max() + 1.01, 1.0)])
    H = H / H.max()
    hull_c = allxy.mean(0)
    hull_r = np.percentile(np.linalg.norm(allxy - hull_c, axis=1), 95)

    recs = []
    for a, b in pairs:
        ps = pair_series(tr, a, b)
        if ps is None:
            continue
        common, xa, xb, va, vb = ps
        dist = np.linalg.norm(xa - xb, axis=1)
        # contiguous time check: split where frames jump
        for s, e in runs(dist <= radius, gap_tol, common):
            if e - s + 1 < min_len:
                continue
            sl = slice(s, e + 1)
            tt = common[sl]; d = dist[sl]
            sa = np.linalg.norm(va[sl], axis=1); sb = np.linalg.norm(vb[sl], axis=1)
            dur = (tt[-1] - tt[0] + 1) * dt
            mid = (xa[sl] + xb[sl]) / 2
            # directionality
            moving = (sa > 0.2) & (sb > 0.2)
            cosang = np.sum(va[sl] * vb[sl], 1) / (sa * sb + 1e-9)
            mean_cos = cosang[moving].mean() if moving.any() else 0.0
            relspeed = np.linalg.norm(va[sl] - vb[sl], axis=1).mean()
            approach = (d[-1] - d[0]) / dur
            # reciprocity
            if len(sa) >= 3 and sa.std() > 1e-6 and sb.std() > 1e-6:
                spcorr = np.corrcoef(sa, sb)[0, 1]
            else:
                spcorr = 0.0
            dspeed = np.abs(sa - sb).mean()
            costop = np.mean((sa < 0.3) & (sb < 0.3))
            # environment: others within ENV_R of midpoint, third parties close to both
            env_n = []; env_v = []; third = {}
            for k, t in enumerate(tt):
                g = fi[t]
                m0 = (g.pid != a) & (g.pid != b)
                if m0.any():
                    gx, gy = g.x[m0], g.y[m0]; gp = g.pid[m0]
                    dd = np.hypot(gx - mid[k, 0], gy - mid[k, 1])
                    m = dd <= ENV_R
                    env_n.append(m.sum())
                    env_v.append(np.hypot(g.vx[m0][m], g.vy[m0][m]).mean() if m.any() else np.nan)
                    da = np.hypot(gx - xa[sl][k, 0], gy - xa[sl][k, 1])
                    db = np.hypot(gx - xb[sl][k, 0], gy - xb[sl][k, 1])
                    for p in gp[(da <= radius) & (db <= radius)]:
                        third[p] = third.get(p, 0) + 1
                else:
                    env_n.append(0); env_v.append(np.nan)
            n_third = sum(1 for p, c in third.items() if c >= 0.5 * len(tt))
            ix = np.clip(((mid[:, 0] - x0) // 1).astype(int), 0, H.shape[0] - 1)
            iy = np.clip(((mid[:, 1] - y0) // 1).astype(int), 0, H.shape[1] - 1)
            occ = H[ix, iy].mean()
            edge = np.linalg.norm(mid - hull_c, axis=1).mean() / hull_r
            env_v = np.array(env_v, float)
            # censoring: episode touches the start/end of the pair's common observation window
            censored = int(s == 0 or e == len(common) - 1)
            # ground truth
            oa, ob = orig(a), orig(b)
            same = (oa in g_of) and (ob in g_of) and g_of[oa] == g_of[ob] and oa != ob
            mspeed = (sa.mean() + sb.mean()) / 2
            if tr_ref is not None:
                ms_ref, near_ref = _ref_state(tr_ref, oa, ob, tt * t_scale, groups, g_of, radius)
            else:
                ms_ref = mspeed
                near_ref = (sum(1 for p in third if g_of.get(orig(p), -1) == g_of.get(oa, -2)
                                and third[p] >= 0.5 * len(tt)) if same else 0)
            if not same:
                ref = "Transit"
            elif ms_ref >= V_STAT:
                ref = "Companionate"
            else:
                ref = "Group" if near_ref >= 1 else "Dyadic"
            recs.append(dict(scene=scene, a=a, b=b, t0=int(tt[0]), t1=int(tt[-1]),
                             cx=mid[:, 0].mean(), cy=mid[:, 1].mean(),
                             # Duration & dwell
                             dur=dur, logdur=np.log(dur), censored=censored,
                             stat_frac=np.mean((sa < V_STAT) & (sb < V_STAT)),
                             # Density
                             d_mean=d.mean(), d_min=d.min(), d_std=d.std(),
                             env_n=np.mean(env_n), n_third=n_third,
                             # Directionality
                             cos_head=mean_cos, relspeed=relspeed, approach=approach,
                             mspeed=mspeed,
                             # Reciprocity
                             spcorr=spcorr, dspeed=dspeed, costop=costop,
                             # Spatial context
                             env_flow=np.nanmean(env_v) if np.isfinite(env_v).any() else 0.0,
                             occ=occ, edge=edge,
                             social=int(same), ref=ref))
    return pd.DataFrame(recs)


def _ref_state(tr_ref, oa, ob, tref, groups, g_of, radius):
    """Clean-data mean speed of the pair and number of other annotated group members
    within `radius` of both for >= 50 % of the interval."""
    sp = []
    pos = {}
    for p in (oa, ob):
        t, xy, v = tr_ref[p]
        m = np.isin(t, tref)
        sp.append(np.linalg.norm(v[m], axis=1).mean() if m.any() else np.nan)
        pos[p] = dict(zip(t[m], xy[m]))
    ms = np.nanmean(sp) if np.isfinite(sp).any() else 0.0
    near = 0
    if oa in g_of and ob in g_of and g_of[oa] == g_of[ob]:
        for q in groups[g_of[oa]]:
            if q in (oa, ob) or q not in tr_ref:
                continue
            t, xy, v = tr_ref[q]; cnt = 0
            for tq, pq in zip(t, xy):
                if tq in pos[oa] and tq in pos[ob]:
                    if np.linalg.norm(pq - pos[oa][tq]) <= radius and np.linalg.norm(pq - pos[ob][tq]) <= radius:
                        cnt += 1
            near += cnt >= 0.5 * len(tref)
    return ms, near


FEATURE_GROUPS = {
    "Duration": ["dur", "logdur", "censored", "stat_frac"],
    "Density": ["d_mean", "d_min", "d_std", "env_n", "n_third"],
    "Directionality": ["cos_head", "relspeed", "approach", "mspeed"],
    "Reciprocity": ["spcorr", "dspeed", "costop"],
    "Context": ["env_flow", "occ", "edge"],
}
ALL_FEATURES = [f for g in FEATURE_GROUPS.values() for f in g]
CLASSES = ["Transit", "Companionate", "Dyadic", "Group"]


def build_all(perturb=None, seed=0):
    """Extract episodes for all scenes. `perturb(df, rng)` may alter trajectories."""
    rng = np.random.default_rng(seed)
    out = []
    for s in SCENES:
        df, groups = load_scene(s)
        if perturb is not None:
            df = perturb(df, rng)
        tr = tracks_from_df(df)
        out.append(extract_episodes(tr, groups, s))
    return pd.concat(out, ignore_index=True)
