"""Code-generated figures 1-5 (replacing the original AI-generated diagrams)."""
import numpy as np, pandas as pd, json, subprocess
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from figs_common import *
import encounter_lib as L
import exp1_thresholds as X1

# ---------------- Figure 1: framework pipeline (Graphviz)
dot1 = r'''digraph G {
 rankdir=LR; nodesep=0.25; ranksep=0.32; bgcolor="white";
 node [shape=box, style="rounded,filled", fillcolor="#f4f7fc", color="#256abf", fontname="DejaVu Sans", fontsize=10, penwidth=1.2, margin="0.12,0.07"];
 edge [color="#52514e", arrowsize=0.7, penwidth=1.1, fontname="DejaVu Sans"];
 S [label=<<b>1 Sensing</b><br/><font point-size="8">camera · BLE · Wi-Fi · GPS</font>>];
 P [label=<<b>2 Preprocessing</b><br/><font point-size="8">trajectories · sync<br/>smoothing · QC</font>>];
 X [label=<<b>3 Proximity model</b><br/><font point-size="8">dᵢⱼ(t) ≤ dₛ ,  τ ≥ tₘᵢₙ<br/>k-d tree, O(N log N + K)</font>>];
 D [label=<<b>4 Detection</b><br/><font point-size="8">episodes · gap tolerance<br/>censoring flag</font>>];
 F [label=<<b>5 Features</b><br/><font point-size="8">duration · density · direction<br/>reciprocity · context</font>>];
 C [label=<<b>6 Classification</b><br/><font point-size="8">explicit rules / learned<br/>reject → Unclassified</font>>];
 V [label=<<b>7 Validation</b><br/><font point-size="8">external ground truth<br/>leave-one-site-out · CIs</font>>, fillcolor="#fff3ec", color="#eb6834"];
 A [label=<<b>8 Aggregation</b><br/><font point-size="8">hotspots · temporal profiles<br/>DP release</font>>];
 Z [label=<<b>9 Design use</b><br/><font point-size="8">diagnosis · intervention<br/>causal evaluation</font>>];
 S->P->X->D->F->C->V->A->Z;
 V->X [style=dashed, color="#eb6834", label=<<font point-size="8" color="#eb6834">recalibrate dₛ, tₘᵢₙ, θ</font>>, constraint=false];
 {rank=same; S; P; X;}
}'''
# wrap into 3x3 snake for page width
dot1 = dot1.replace('rankdir=LR;', 'rankdir=TB;').replace(
    '{rank=same; S; P; X;}', '{rank=same; S; P; X;} {rank=same; D; F; C;} {rank=same; V; A; Z;}')
dot1 = dot1.replace('S->P->X->D->F->C->V->A->Z;',
                    'S->P->X; X->D [constraint=true]; D->F->C; C->V; V->A->Z; '
                    'S->D [style=invis]; D->V [style=invis]; P->F [style=invis]; F->A [style=invis]; X->C [style=invis]; C->Z [style=invis];')
open(f"{FIG}/fig1.dot", "w").write(dot1)
subprocess.run(["dot", "-Tpng", "-Gdpi=300", f"{FIG}/fig1.dot", "-o", f"{FIG}/fig1_framework.png"], check=True)

# ---------------- Figure 3: taxonomy as an explicit decision procedure (Graphviz)
dot3 = r'''digraph T {
 rankdir=TB; nodesep=0.3; ranksep=0.32; bgcolor="white";
 node [fontname="DejaVu Sans", fontsize=9.5, penwidth=1.1];
 edge [fontname="DejaVu Sans", fontsize=8.5, color="#52514e", arrowsize=0.7, fontcolor="#52514e"];
 node [shape=box, style="rounded", color="#52514e"];
 e  [label=<Candidate episode <i>e</i> = (<i>i</i>, <i>j</i>, [<i>t</i><sub>0</sub>, <i>t</i><sub>1</sub>]):  <i>d<sub>ij</sub></i>(<i>t</i>) ≤ <i>D<sub>c</sub></i>, gaps ≤ <i>g</i>, τ ≥ 3Δ<i>t</i>>];
 m  [label=<Margin test: any |<i>x<sub>k</sub></i> − θ<sub><i>k</i></sub>| &lt; δ<sub><i>k</i></sub>  or  max<sub><i>c</i></sub> <i>p</i>(<i>c</i>|<i>x</i>) &lt; ρ ?>];
 s  [label=<Social co-presence <i>S</i>(<i>e</i>):<br/><i>d̄</i> ≤ θ<sub><i>d</i></sub> ∧ τ ≥ θ<sub>τ</sub> ∧ Δ<i>v̄</i> ≤ θ<sub><i>v</i></sub> ∧ ( <i>c̄</i> ≥ θ<sub><i>c</i></sub> ∨ <i>f</i><sub>stat</sub> ≥ ½ )>];
 v  [label=<Moving together?  <i>v̄</i> ≥ <i>v<sub>s</sub></i>>];
 g  [label=<Third party co-present?  <i>n</i><sub>3</sub> ≥ 1>];
 d  [label=<Duration  τ ≥ τ<sub><i>S</i></sub>>];
 node [shape=box, style="rounded,filled"];
 c6 [label=<<b>6 Unclassified</b><br/><font point-size="8">reject option</font>>, fillcolor="#f0efec", color="#8a8985"];
 c1 [label=<<b>1 Transit Crossing</b>>, fillcolor="#f0efec", color="#8a8985"];
 c5 [label=<<b>5 Companionate Movement</b>>, fillcolor="#e6f0fb", color="#2a78d6"];
 c4 [label=<<b>4 Group Encounter</b>>, fillcolor="#e3f5ee", color="#1baf7a"];
 c2 [label=<<b>2 Brief Encounter</b>>, fillcolor="#fdeee6", color="#eb6834"];
 c3 [label=<<b>3 Sustained Dyadic</b>>, fillcolor="#fdeee6", color="#eb6834"];
 e -> m;  m -> c6 [label=" yes"];  m -> s [label=" no"];
 s -> c1 [label=" no"];  s -> v [label=" yes"];
 v -> c5 [label=" yes"]; v -> g [label=" no"];
 g -> c4 [label=" yes"]; g -> d [label=" no"];
 d -> c2 [label=" no"];  d -> c3 [label=" yes"];
}'''
open(f"{FIG}/fig3.dot", "w").write(dot3)
subprocess.run(["dot", "-Tpng", "-Gdpi=300", f"{FIG}/fig3.dot", "-o", f"{FIG}/fig3_taxonomy.png"], check=True)

# ---------------- Figure 2: movement-centric vs encounter-centric view of the same space
E = pd.read_csv("../results/episodes_clean.csv")
df, groups = L.load_scene("Students")
fig, ax = plt.subplots(1, 2, figsize=(6.6, 3.2), sharex=True, sharey=True)
for pid, g in df.groupby("pid"):
    ax[0].plot(g.x, g.y, color=S1, lw=0.35, alpha=0.35)
ax[0].set_title("(a) Movement view: 428 trajectories", loc="left")
Es = E[E.scene == "Students"]
for c in ["Transit", "Companionate", "Dyadic", "Group"]:
    q = Es[Es.ref == c]
    ax[1].scatter(q.cx, q.cy, s=6 if c == "Transit" else 14, color=CLASS_COL[c],
                  alpha=0.35 if c == "Transit" else 0.95, lw=0.3 if c != "Transit" else 0,
                  edgecolor="white", label=f"{CLASS_LAB[c]} (n={len(q)})",
                  marker={"Transit": ".", "Companionate": "o", "Dyadic": "s", "Group": "^"}[c])
ax[1].set_title("(b) Encounter view: co-presence episodes", loc="left")
for a in ax:
    a.set_aspect("equal"); a.set_xlabel("x (m)")
ax[0].set_ylabel("y (m)")
ax[1].legend(loc="upper center", bbox_to_anchor=(-0.08, -0.2), ncol=2, fontsize=7.5, markerscale=1.3)
save(fig, "fig2_movement_vs_encounter")

# ---------------- Figure 4: threshold calibration
tabs = np.load("../results/exp1_tables.npy", allow_pickle=True).item()
T1 = pd.read_csv("../results/exp1_thresholds.csv"); meta = pd.read_csv("../results/exp1_meta.csv")
cmap = LinearSegmentedColormap.from_list("seq", ["#fcfcfb"] + SEQ)
fig, axs = plt.subplots(2, 3, figsize=(6.8, 5.4))
fig.subplots_adjust(wspace=0.38, hspace=0.62, bottom=0.2, right=0.98)
tmask = X1.T_GRID <= 20
for k, s in enumerate(L.SCENES):
    a = axs.flat[k]
    y, M = tabs[f"Truth|{s}"]
    f1 = X1.f1_grid(y, M)[0][:, tmask]
    im = a.imshow(f1, origin="lower", aspect="auto", cmap=cmap, vmin=0, vmax=1,
                  extent=[X1.T_GRID[tmask][0] - 0.2, X1.T_GRID[tmask][-1] + 0.2, X1.DS_GRID[0] - 0.125, X1.DS_GRID[-1] + 0.125])
    r = T1[(T1.modality == "Truth") & (T1.scene == s)].iloc[0]
    a.plot(r.oracle_t, r.oracle_ds, marker="*", ms=10, color=S2, mec="white", mew=0.6, ls="none")
    a.plot(r.loso_t, r.loso_ds, marker="o", ms=6, mfc="none", mec=INK, mew=1.2, ls="none")
    m = meta[(meta.modality == "Truth") & (meta.scene == s)].iloc[0]
    a.set_title(f"{s}\n{m.mean_per_frame:.0f} ped/frame · NN {m.median_nn:.2f} m", fontsize=8, loc="left")
    a.grid(False)
    if k % 3 == 0: a.set_ylabel("$d_s$ (m)")
    if k >= 2: a.set_xlabel("$t_{min}$ (s)")
    a.text(0.97, 0.95, f"best F1 {r.oracle_f1:.2f}\nLOSO F1 {r.loso_f1:.2f}", transform=a.transAxes,
           ha="right", va="top", fontsize=7, color=INK,
           bbox=dict(boxstyle="round,pad=0.2", fc="white", ec="none", alpha=0.85))
# panel 6: modality comparison
a = axs.flat[5]
mods = ["Truth", "Camera", "BLE", "GPS"]; cols = [INK2, S1, S2, S3]
for i, md in enumerate(mods):
    q = T1[T1.modality == md]
    a.scatter(np.full(len(q), i) + np.linspace(-0.12, 0.12, len(q)), q.loso_f1, s=12, color=cols[i], zorder=3)
    a.plot([i - 0.25, i + 0.25], [q.loso_f1.mean()] * 2, color=cols[i], lw=2)
    a.text(i + 0.28, q.loso_f1.mean(), f"{q.loso_f1.mean():.2f}", ha="left", va="center", fontsize=7, color=INK)
a.set_xticks(range(4)); a.set_xticklabels(["Annot.", "Cam.", "BLE", "GPS"], fontsize=7.5); a.set_xlim(-0.5, 3.9)
a.set_ylim(0, 1); a.set_ylabel("LOSO-calibrated F1")
a.set_title("Transfer F1 by\nsensing modality", fontsize=8, loc="left")
cax = fig.add_axes([0.13, 0.075, 0.5, 0.018]); cb = fig.colorbar(im, cax=cax, orientation="horizontal")
cb.set_label("F1 vs annotated groups", labelpad=2); cax.xaxis.set_label_position("top")
fig.text(0.13, -0.005, "★ scene-optimal thresholds   ○ thresholds calibrated on the other four scenes (LOSO)",
         fontsize=7.5, color=INK2)
save(fig, "fig4_threshold_calibration")

# ---------------- Figure 5: validation scheme vs method; confusion matrices
A = pd.read_csv("../results/exp2_methods_cv.csv")
pc = json.load(open("../results/exp2_perclass.json"))
fig = plt.figure(figsize=(6.8, 5.2))
gs = fig.add_gridspec(2, 2, height_ratios=[1.05, 1], hspace=0.55, wspace=0.35)
a = fig.add_subplot(gs[0, :])
methods = ["Rule-based", "Logistic regression", "Random forest", "Gradient boosting", "Unsupervised GMM", "Hybrid"]
schemes = [("Random 5-fold", S2, "s"), ("Temporal block", S4, "D"), ("LOSO", S1, "o")]
for j, (sc, col, mk) in enumerate(schemes):
    q = A[A.scheme == sc].set_index("method").loc[methods]
    x = np.arange(len(methods)) + (j - 1) * 0.22
    a.errorbar(x, q.macroF1, yerr=[q.macroF1 - q.ci_lo, q.ci_hi - q.macroF1], fmt=mk, ms=5, color=col,
               ecolor=col, elinewidth=1.2, capsize=0, label=sc if sc != "LOSO" else "Leave-one-scene-out")
a.set_xticks(range(len(methods))); a.set_xticklabels(["Rule-based\n(explicit)", "Logistic\nregression", "Random\nforest",
                                                       "Gradient\nboosting", "Unsupervised\nGMM", "Hybrid\n(GMM+RF)"], fontsize=7.5)
a.set_ylabel("Macro-F1 (4 classes)"); a.set_ylim(0.25, 0.9)
a.legend(ncol=3, loc="upper left", fontsize=7.5)
a.set_title("(a) Same models, three validation designs (95% pair-cluster bootstrap CIs)", loc="left")
for k, (mname, title) in enumerate([("Rule-based", "(b) Rule-based, LOSO"), ("Random forest", "(c) Random forest, LOSO")]):
    a = fig.add_subplot(gs[1, k])
    cm = np.array(pc[mname]["cm"], float); cmn = cm / cm.sum(1, keepdims=True)
    a.imshow(cmn, cmap=cmap, vmin=0, vmax=1); a.grid(False)
    labs = ["Trans.", "Comp.", "Dyad", "Group"]
    a.set_xticks(range(4)); a.set_yticks(range(4)); a.set_xticklabels(labs, fontsize=7.5); a.set_yticklabels(labs, fontsize=7.5)
    for i in range(4):
        for j in range(4):
            a.text(j, i, f"{cmn[i, j]:.2f}\n({int(cm[i, j])})", ha="center", va="center", fontsize=6.5,
                   color="white" if cmn[i, j] > 0.55 else INK)
    a.set_xlabel("Predicted"); a.set_ylabel("Reference" if k == 0 else "")
    a.set_title(title, loc="left")
save(fig, "fig5_validation_confusion")
print("ok")
