"""Experiment 3b: ablation of the explicit decision rule (each condition of Eq. 4 and the
n3 test removed in turn, thresholds re-calibrated under LOSO), plus paired-bootstrap CIs
on social-F1 for the random-forest feature-group ablation."""
import numpy as np, pandas as pd, itertools, warnings
import encounter_lib as L
from exp2_classification import E, SCN, macro, binf1, paired_boot_diff, RuleBased, rf

warnings.filterwarnings("ignore")
y = E.y.values; pairs = E.pair.values


class AblatedRule(RuleBased):
    def __init__(self, drop):
        self.drop = drop

    def _pred(self, X, td, tt, tc, tv):
        ok = np.ones(len(X), bool)
        if self.drop != "Density (distance)": ok &= X.d_mean <= td
        if self.drop != "Duration": ok &= X.dur >= tt
        if self.drop != "Reciprocity (speed difference)": ok &= X.dspeed <= tv
        if self.drop != "Directionality / dwell": ok &= (X.cos_head >= tc) | (X.stat_frac >= 0.5)
        moving = X.mspeed >= L.V_STAT
        p = np.zeros(len(X), int)
        p[ok & moving] = 1
        if self.drop == "Density (third parties)":
            p[ok & ~moving] = 2
        else:
            p[ok & ~moving & (X.n_third == 0)] = 2
            p[ok & ~moving & (X.n_third >= 1)] = 3
        return p


def loso(drop):
    p = np.zeros(len(E), int)
    for s in SCN:
        tr = (E.scene != s).values
        m = AblatedRule(drop).fit(E[tr], y[tr]); p[~tr] = m.predict(E[~tr])
    return p


full = loso(None)
rows = [dict(removed="none (full rule)", macroF1=macro(y, full), socialF1=binf1(y, full),
             d_macro=0, lo_m=0, hi_m=0, d_social=0, lo_s=0, hi_s=0)]
for drop in ["Density (distance)", "Duration", "Reciprocity (speed difference)", "Directionality / dwell",
             "Density (third parties)"]:
    p = loso(drop)
    dm, cim, _ = paired_boot_diff(y, p, full, pairs, macro, B=1000)
    ds, cis, _ = paired_boot_diff(y, p, full, pairs, binf1, B=1000)
    rows.append(dict(removed=drop, macroF1=macro(y, p), socialF1=binf1(y, p), d_macro=dm, lo_m=cim[0], hi_m=cim[1],
                     d_social=ds, lo_s=cis[0], hi_s=cis[1]))
    print(rows[-1], flush=True)
pd.DataFrame(rows).to_csv("../results/exp3b_rule_ablation.csv", index=False)

# social-F1 CIs for RF feature-group ablation (re-using the same LOSO protocol, 300 trees)
FE = L.ALL_FEATURES


def loso_rf(feats):
    p = np.zeros(len(E), int)
    for s in SCN:
        tr = (E.scene != s).values
        p[~tr] = rf(0, n_estimators=300).fit(E.loc[tr, feats].values, y[tr]).predict(E.loc[~tr, feats].values)
    return p


fullrf = loso_rf(FE); out = []
for g, fs in L.FEATURE_GROUPS.items():
    p = loso_rf([f for f in FE if f not in fs])
    ds, cis, pv = paired_boot_diff(y, p, fullrf, pairs, binf1, B=1000)
    out.append(dict(without=g, socialF1=binf1(y, p), d_social=ds, lo=cis[0], hi=cis[1], p=pv))
    print(out[-1], flush=True)
pd.DataFrame(out).to_csv("../results/exp3b_rf_social_ablation.csv", index=False)
