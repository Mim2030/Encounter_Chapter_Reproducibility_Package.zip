"""Experiment 4b (BLE shadowing and sampling bias parts of Experiment 4): quantitative sensitivity analyses.
(a) positional noise, (b) temporal sampling rate, (c) occlusion / ID switches,
(d) field-of-view truncation (sensor boundary effects), (e) BLE RSSI shadowing,
(f) device-penetration and demographic sampling bias.
Classifier: RF, LOSO; reference labels always from clean annotated tracks."""
import numpy as np, pandas as pd, time, warnings
import encounter_lib as L
from exp2_classification import macro, binf1, rf, RuleBased
from exp1_thresholds import pair_table, f1_grid, DS_GRID, T_GRID, ble_distance
import exp1_thresholds as X1

warnings.filterwarnings("ignore")
FEATS = L.ALL_FEATURES
t0 = time.time()


def evaluate(E):
    E = E.copy(); E["y"] = E.ref.map({c: i for i, c in enumerate(L.CLASSES)})
    p = np.zeros(len(E), int)
    for s in L.SCENES:
        tr = (E.scene != s).values; te = ~tr
        m = rf(0, n_estimators=200).fit(E.loc[tr, FEATS].values, E.y.values[tr])
        p[te] = m.predict(E.loc[te, FEATS].values)
    pr = np.zeros(len(E), int)
    for s in L.SCENES:
        tr = (E.scene != s).values; te = ~tr
        pr[te] = RuleBased().fit(E[tr], E.y.values[tr]).predict(E[te])
    global LAST_RULE
    LAST_RULE = (macro(E.y.values, pr), binf1(E.y.values, pr))
    return macro(E.y.values, p), binf1(E.y.values, p), len(E), E


def run(perturb_df=None, dt_mult=1, smooth=False, seed=0, fov=None):
    """perturb_df(df, rng) -> (df_perturbed, orig_fn)."""
    rng = np.random.default_rng(seed)
    out = []
    for s in L.SCENES:
        df, groups = L.load_scene(s)
        tr_ref = L.tracks_from_df(df)
        orig = None
        dfp = df
        if fov is not None:
            cx, cy = df.x.median(), df.y.median()
            hx = (df.x.quantile(.98) - df.x.quantile(.02)) * fov / 2
            hy = (df.y.quantile(.98) - df.y.quantile(.02)) * fov / 2
            dfp = df[(np.abs(df.x - cx) <= hx) & (np.abs(df.y - cy) <= hy)]
        if perturb_df is not None:
            dfp, orig = perturb_df(dfp, rng)
        if dt_mult > 1:
            dfp = dfp[dfp.t % dt_mult == 0].copy(); dfp["t"] //= dt_mult
        tr = L.tracks_from_df(dfp, dt=L.DT * dt_mult, smooth=smooth)
        tr = {k: v for k, v in tr.items() if len(v[0]) >= 1}
        min_len = 3 if dt_mult == 1 else 2
        out.append(L.extract_episodes(tr, groups, s, dt=L.DT * dt_mult, tr_ref=tr_ref, orig=orig,
                                      t_scale=dt_mult, min_len=min_len))
    return pd.concat(out, ignore_index=True)


def noise(sigma):
    def f(df, rng):
        d = df.copy()
        # temporally correlated error per person (AR(1), rho=0.9) + white jitter
        for pid, idx in d.groupby("pid").groups.items():
            n = len(idx)
            e = np.c_[X1.ar1(n, sigma, 0.9, rng), X1.ar1(n, sigma, 0.9, rng)]
            d.loc[idx, ["x", "y"]] += e
        return d, None
    return f


def occlusion(rate, switch_p=0.5, mean_len_s=2.0):
    """Each track enters occlusion with hazard `rate` per frame; occluded frames are dropped;
    after an occlusion the ID switches with probability switch_p."""
    def f(df, rng):
        d = df.reset_index(drop=True)
        keep = np.ones(len(d), bool); newpid = d.pid.values.copy()
        mean_len = mean_len_s / L.DT
        for pid, idx in d.groupby("pid").indices.items():
            idx = idx[np.argsort(d.t.values[idx])]
            n = len(idx); k = 0; seg = 0
            while k < n:
                if rng.random() < rate:
                    ln = rng.geometric(1 / mean_len)
                    keep[idx[k:k + ln]] = False
                    k += ln
                    if rng.random() < switch_p:
                        seg += 1
                    continue
                newpid[idx[k]] = pid * 1000 + seg if seg else pid
                k += 1
        d["pid"] = newpid; d = d[keep]
        return d, (lambda p: p // 1000 if p >= 1000 else p)
    return f


if __name__ == "__main__":
    # (e) BLE shadowing: threshold detector, LOSO-calibrated (d_s, t_min)
    ble = []
    for sdb in [2, 4, 6, 8, 10]:
        orig_fn = X1.ble_distance
        X1.ble_distance = lambda d, rng, s=sdb: orig_fn(d, rng, sigma_db=s)
        tabs = {s: pair_table(s, "BLE")[:2] for s in L.SCENES}
        X1.ble_distance = orig_fn
        grids = {s: f1_grid(*tabs[s])[0] for s in L.SCENES}
        f1s = []; dss = []
        for s in L.SCENES:
            other = np.mean([grids[o] for o in L.SCENES if o != s], axis=0)
            i, j = np.unravel_index(np.argmax(other), other.shape)
            f1s.append(X1.f1_at(*tabs[s], DS_GRID[i], T_GRID[j])[0]); dss.append(DS_GRID[i])
        ble.append(dict(sigma_db=sdb, mean_loso_f1=np.mean(f1s), min_f1=np.min(f1s), max_f1=np.max(f1s),
                        median_calibrated_ds=np.median(dss)))
        print(ble[-1], round(time.time() - t0), flush=True)
    pd.DataFrame(ble).to_csv("../results/exp4_ble.csv", index=False)

    # (f) device penetration & correlated (demographic) sampling bias, on clean episodes
    Ec = pd.read_csv("../results/episodes_clean.csv")
    persons = {(r.scene, p) for r in Ec.itertuples() for p in (r.a, r.b)}
    soc_people = {(r.scene, p) for r in Ec[Ec.social == 1].itertuples() for p in (r.a, r.b)}
    true_share = Ec.social.mean(); true_n = len(Ec)
    bias = []
    rng = np.random.default_rng(5)
    for q_solo, q_grp, label in [(1, 1, "full"), (0.5, 0.5, "uniform 50%"), (0.25, 0.25, "uniform 25%"),
                                 (0.6, 0.3, "groups under-sampled"), (0.3, 0.6, "groups over-sampled")]:
        est_n, est_share, ipw_share, naive_n = [], [], [], []
        for rep in range(200):
            carry = {pp: rng.random() < (q_grp if pp in soc_people else q_solo) for pp in persons}
            obs = Ec[[carry[(s, a)] and carry[(s, b)] for s, a, b in zip(Ec.scene, Ec.a, Ec.b)]]
            qa = np.array([q_grp if (s, a) in soc_people else q_solo for s, a in zip(obs.scene, obs.a)])
            qb = np.array([q_grp if (s, b) in soc_people else q_solo for s, b in zip(obs.scene, obs.b)])
            w = 1 / (qa * qb)
            est_n.append(w.sum() / true_n); naive_n.append(len(obs) / true_n)
            est_share.append(obs.social.mean())
            ipw_share.append((w * obs.social).sum() / w.sum())
        bias.append(dict(scenario=label, q_solo=q_solo, q_group=q_grp,
                         naive_count_ratio=np.mean(naive_n),
                         ipw_count_ratio=np.mean(est_n), naive_social_share=np.mean(est_share),
                         ipw_social_share=np.mean(ipw_share), true_social_share=true_share,
                         share_rel_bias=np.mean(est_share) / true_share - 1))
        print(bias[-1], flush=True)
    pd.DataFrame(bias).to_csv("../results/exp4_sampling_bias.csv", index=False)
    print("done", round(time.time() - t0))
