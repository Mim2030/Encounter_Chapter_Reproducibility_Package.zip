# Reproducibility package: Encounter Classification for Data-Driven Intelligent Urban Design

Regenerates every table and figure in the revised chapter's Experimental Evaluation.

## Data
Public ETH/UCY pedestrian sequences with group annotations, as distributed by OpenTraj:

    git clone --depth 1 https://github.com/crowdbotp/OpenTraj.git

Set `DATA_ROOT` in `encounter_lib.py` to `<clone>/datasets`. Scenes used: ETH/seq_eth, ETH/seq_hotel,
UCY/zara01, UCY/zara02, UCY/students03 (files `obsmat.txt` and `groups.txt`).

## Environment
Python 3.13, numpy 2.5, pandas 3.0, scikit-learn 1.9, scipy 1.18, statsmodels, dp-accounting, matplotlib 3.11,
Graphviz `dot` (for Figures 1 and 3). All random seeds are fixed.

## Run order (from this folder)
| Script | Output (../results) | Chapter element |
|---|---|---|
| `python -c "import encounter_lib as L; L.build_all().to_csv('../results/episodes_clean.csv', index=False)"` | episodes_clean.csv | Table 5 |
| `exp1_thresholds.py` | exp1_*.csv | Threshold calibration, Fig. 4 |
| `exp2_classification.py` | exp2_*.csv/json | Table 7, Fig. 5, significance tests |
| `exp3_ablation_budget.py` | exp3_*.csv | RF ablation, hyperparameters, reject option, label budget (its final clustering step is superseded by exp3d) |
| `exp3d_nclusters.py` | exp3_nclusters.csv | Number-of-classes analysis |
| `exp3b_rule_ablation.py` | exp3b_*.csv | Table 8 |
| `exp3c_rule_budget.py` | exp3c_rule_budget.csv | Fig. 6 (rule-based curve) |
| `exp4_sensitivity.py` | exp4_sensitivity.csv | Sensitivity, Fig. 7 |
| `exp4b_ble_bias.py` | exp4_ble.csv, exp4_sampling_bias.csv | BLE shadowing, penetration bias |
| `exp4c_ble_seeds.py` | exp4c_ble_seeds.csv | BLE shadowing, three seeds per level |
| `exp5_privacy.py` | exp5_*.csv | Federated learning rows of Table 9 |
| `exp7_review.py` | exp7_*.csv/json | Annotation-only task, sub-class agreement, zero-label thresholds, episode-level DP (Table 9), spatial analysis |
| `exp6_scalability.py` | exp6_*.csv | Scalability, Fig. 8(a) |
| `exp6b_memory.py` | exp6_memory_rss.csv | Fig. 8(b) |
| `build_docx.py` | revised .docx | Chapter assembly from chapter_source.md |
| `figs_part1.py`, `figs_part2.py`, `figs_part3.py` | ../figs/*.png | Figures 1–9 |

Runtime: about one hour on a two-core machine. BLE, GPS, occlusion, field-of-view and penetration conditions are
simulations applied to annotated trajectories, with the error models stated in the chapter and in the code.

Note: the hotspot rows of Table 9 come from exp7_review.py (episode-level DP). exp5_privacy.py also writes an earlier
person-bounded variant (exp5_dp_hotspots.csv) that is no longer reported, because greedy bounding of pairwise episodes
does not bound person-level sensitivity.
