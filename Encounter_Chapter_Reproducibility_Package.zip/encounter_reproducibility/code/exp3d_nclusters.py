"""Experiment 3d: how many clusters does the 19-feature space support? GMM BIC (k=1..12),
k-means silhouette, bootstrap stability and agreement (ARI) with the reference classes."""
import numpy as np, pandas as pd, warnings
from sklearn.preprocessing import PowerTransformer
from sklearn.mixture import GaussianMixture
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score, adjusted_rand_score
import encounter_lib as L

warnings.filterwarnings("ignore")
E = pd.read_csv("../results/episodes_clean.csv")
y = E.ref.map({c: i for i, c in enumerate(L.CLASSES)}).values
Z = PowerTransformer().fit_transform(E[L.ALL_FEATURES].values)
rng = np.random.default_rng(0); sub = rng.choice(len(Z), 3000, replace=False)
rows = []
for k in range(1, 13):
    g = GaussianMixture(k, covariance_type="full", reg_covar=1e-3, random_state=0).fit(Z)
    row = dict(k=k, bic=g.bic(Z))
    if k >= 2:
        km = KMeans(k, n_init=4, random_state=0).fit(Z)
        row["silhouette"] = silhouette_score(Z[sub], km.labels_[sub])
        row["ARI_kmeans_vs_reference"] = adjusted_rand_score(y, km.labels_)
        row["ARI_gmm_vs_reference"] = adjusted_rand_score(y, g.predict(Z))
        aris = []
        for b in range(5):
            bi = rng.choice(len(Z), len(Z), replace=True)
            kb = KMeans(k, n_init=2, random_state=b).fit(Z[bi])
            aris.append(adjusted_rand_score(km.labels_, kb.predict(Z)))
        row["stability_ARI"] = float(np.mean(aris))
    rows.append(row); print(row, flush=True)
pd.DataFrame(rows).to_csv("../results/exp3_nclusters.csv", index=False)
