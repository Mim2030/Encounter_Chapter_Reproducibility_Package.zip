"""Experiment 3: feature-group ablation, label-budget (supervised vs unsupervised vs
hybrid), reject option (Unclassified), number-of-classes analysis, RF hyperparameter
robustness. All under leave-one-scene-out (LOSO)."""
import numpy as np, pandas as pd, json, time, warnings
from sklearn.preprocessing import StandardScaler, PowerTransformer
from sklearn.mixture import GaussianMixture
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score, adjusted_rand_score, f1_score
import encounter_lib as L
from exp2_classification import E, FEATS, SCN, macro, binf1, rf, paired_boot_diff

warnings.filterwarnings("ignore")
y = E.y.values; pairs = E.pair.values
t0 = time.time()


def loso_rf(feats, seed=0, **kw):
    p = np.zeros(len(E), int); P = np.zeros((len(E), 4))
    for s in SCN:
        tr = (E.scene != s).values; te = ~tr
        m = rf(seed, n_estimators=300, **kw).fit(E.loc[tr, feats].values, y[tr])
        pp = m.predict_proba(E.loc[te, feats].values)
        full = np.zeros((te.sum(), 4)); full[:, m.classes_] = pp
        P[te] = full; p[te] = full.argmax(1)
    return p, P


# ---------------- 1. ablation
full_p, full_P = loso_rf(FEATS)
np.save("../results/exp3_rf_proba.npy", full_P)
rows = [dict(config="All five dimensions", macroF1=macro(y, full_p), socialF1=binf1(y, full_p),
             d=0, lo=0, hi=0, p=1)]
for g, fs in L.FEATURE_GROUPS.items():
    for mode in ["without", "only"]:
        feats = [f for f in FEATS if f not in fs] if mode == "without" else fs
        p, _ = loso_rf(feats)
        d, ci, pv = paired_boot_diff(y, p, full_p, pairs, macro, B=1000)
        rows.append(dict(config=f"{mode} {g}", macroF1=macro(y, p), socialF1=binf1(y, p),
                         d=d, lo=ci[0], hi=ci[1], p=pv))
        print(rows[-1], round(time.time() - t0), flush=True)
pd.DataFrame(rows).to_csv("../results/exp3_ablation.csv", index=False)

# ---------------- 2. hyperparameter robustness
hp = []
for msl in [1, 2, 5, 10]:
    for mf in ["sqrt", 0.5]:
        p, _ = loso_rf(FEATS, min_samples_leaf=msl, max_features=mf)
        hp.append(dict(min_samples_leaf=msl, max_features=str(mf), macroF1=macro(y, p), socialF1=binf1(y, p)))
pd.DataFrame(hp).to_csv("../results/exp3_hyperparams.csv", index=False)
print(pd.DataFrame(hp), flush=True)

# ---------------- 3. reject option -> Unclassified class
conf = full_P.max(1)
rej = []
for tau in [0.0, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]:
    acc = conf >= tau
    rej.append(dict(tau=tau, coverage=acc.mean(), macroF1_accepted=macro(y[acc], full_p[acc]),
                    socialF1_accepted=binf1(y[acc], full_p[acc]),
                    **{f"rejected_{c}": float(np.mean(~acc[y == i])) for i, c in enumerate(L.CLASSES)}))
pd.DataFrame(rej).to_csv("../results/exp3_reject.csv", index=False)
print(pd.DataFrame(rej).round(3), flush=True)

# ---------------- 4. label budget: supervised vs unsupervised(mapped) vs hybrid
pt_cache = {}; gmm_cache = {}
for s in SCN:
    tr = (E.scene != s).values
    pt = PowerTransformer().fit(E.loc[tr, FEATS].values)
    Z = pt.transform(E.loc[tr, FEATS].values)
    best = None
    for k in range(2, 13):
        g = GaussianMixture(k, covariance_type="full", reg_covar=1e-3, random_state=0).fit(Z)
        b = g.bic(Z)
        if best is None or b < best[0]:
            best = (b, k, g)
    pt_cache[s] = pt; gmm_cache[s] = best[2]
    print("fold", s, "BIC-selected K =", best[1], flush=True)


def class_map(comp, yl, k):
    w = len(yl) / (4 * np.maximum(np.bincount(yl, minlength=4), 1))
    return np.array([int(np.argmax(np.bincount(yl[comp == c], weights=w[yl[comp == c]], minlength=4)))
                     if (comp == c).any() else 0 for c in range(k)])


budget = []
for frac in [0.01, 0.02, 0.05, 0.10, 0.25, 0.50, 1.0]:
    for seed in range(5):
        rng = np.random.default_rng(seed)
        preds = {m: np.zeros(len(E), int) for m in ["Supervised RF", "Unsupervised GMM", "Hybrid"]}
        for s in SCN:
            tr_idx = np.flatnonzero((E.scene != s).values); te = (E.scene == s).values
            # random labelled subset, guaranteeing >=2 examples of each class present
            n_lab = max(int(frac * len(tr_idx)), 8)
            lab = set(rng.choice(tr_idx, n_lab, replace=False))
            for c in range(4):
                ci = tr_idx[y[tr_idx] == c]
                if len(ci):
                    lab |= set(rng.choice(ci, min(2, len(ci)), replace=False))
            lab = np.array(sorted(lab)); unl = np.setdiff1d(tr_idx, lab)
            X = E[FEATS].values
            # supervised on labelled only
            m = rf(seed, n_estimators=300).fit(X[lab], y[lab])
            preds["Supervised RF"][te] = m.predict(X[te])
            # unsupervised GMM: discovered on all training data, mapped with labelled subset
            pt, g = pt_cache[s], gmm_cache[s]
            comp_lab = g.predict(pt.transform(X[lab]))
            cmap = class_map(comp_lab, y[lab], g.n_components)
            preds["Unsupervised GMM"][te] = cmap[g.predict(pt.transform(X[te]))]
            # hybrid: pseudo-label confident unlabelled episodes + posterior features
            Pu = g.predict_proba(pt.transform(X[unl])) if len(unl) else np.zeros((0, g.n_components))
            confm = Pu.max(1) >= 0.9 if len(unl) else np.zeros(0, bool)
            Xs = np.vstack([X[lab], X[unl][confm]]); ys = np.concatenate([y[lab], cmap[Pu.argmax(1)][confm]])
            aug = lambda A: np.hstack([A, g.predict_proba(pt.transform(A))])
            mh = rf(seed, n_estimators=300).fit(aug(Xs), ys)
            preds["Hybrid"][te] = mh.predict(aug(X[te]))
        for mname, p in preds.items():
            budget.append(dict(frac=frac, seed=seed, method=mname, macroF1=macro(y, p), socialF1=binf1(y, p)))
        print(frac, seed, {r["method"]: round(r["macroF1"], 3) for r in budget[-3:]}, round(time.time() - t0), flush=True)
        if frac == 1.0:
            break   # deterministic subset at 100 %
pd.DataFrame(budget).to_csv("../results/exp3_budget.csv", index=False)

# ---------------- 5. how many classes does the feature space support?
Z = PowerTransformer().fit_transform(E[FEATS].values)
kr = []
rng = np.random.default_rng(0)
sub = rng.choice(len(Z), 4000, replace=False)
for k in range(1, 13):
    g = GaussianMixture(k, covariance_type="full", reg_covar=1e-3, random_state=0).fit(Z)
    row = dict(k=k, bic=g.bic(Z))
    if k >= 2:
        km = KMeans(k, n_init=10, random_state=0).fit(Z)
        row["silhouette"] = silhouette_score(Z[sub], km.labels_[sub])
        row["ARI_vs_reference"] = adjusted_rand_score(y, km.labels_)
        # bootstrap stability
        aris = []
        for b in range(10):
            bi = rng.choice(len(Z), len(Z), replace=True)
            kb = KMeans(k, n_init=5, random_state=b).fit(Z[bi])
            aris.append(adjusted_rand_score(km.labels_, kb.predict(Z)))
        row["stability_ARI"] = float(np.mean(aris))
    kr.append(row); print(row, flush=True)
pd.DataFrame(kr).to_csv("../results/exp3_nclusters.csv", index=False)
print("done", round(time.time() - t0))
