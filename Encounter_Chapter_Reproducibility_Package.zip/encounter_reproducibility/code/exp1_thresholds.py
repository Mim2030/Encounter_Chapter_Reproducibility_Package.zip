"""Experiment 1: empirical threshold calibration (d_s, t_min) against human group
annotations, per scene and per simulated sensing modality, with LOSO transfer."""
import numpy as np, pandas as pd, json
from itertools import combinations
import encounter_lib as L

DS_GRID = np.round(np.arange(0.5, 5.01, 0.25), 2)
T_GRID = np.round(np.concatenate([np.arange(0.4, 20.01, 0.4), [30, 45, 60]]), 1)
RNG = np.random.default_rng(42)


def maxrun_seconds(dist, ds, dt, gap=L.GAP_TOL):
    r = L.runs(dist <= ds, gap)
    if not r:
        return 0.0
    return max((e - s + 1) for s, e in r) * dt


# ---------- sensing-modality simulators (operate on per-person tracks) ----------
def ar1(n, sigma, rho, rng):
    e = np.empty(n); e[0] = rng.normal(0, sigma)
    for k in range(1, n):
        e[k] = rho * e[k - 1] + rng.normal(0, sigma * np.sqrt(1 - rho ** 2))
    return e


def modality_tracks(tr, modality, rng):
    """Return (tracks, dt, distance_fn). distance_fn(pair_series) -> distance array."""
    if modality == "Camera":
        out = {}
        for p, (t, xy, v) in tr.items():
            out[p] = (t, xy + rng.normal(0, 0.15, xy.shape), v)
        return out, L.DT
    if modality == "GPS":
        out = {}
        for p, (t, xy, v) in tr.items():
            keep = (t % 3) == 0          # 1.2 s sampling
            n = keep.sum()
            if n == 0:
                continue
            err = np.c_[ar1(n, 4.0, 0.9, rng), ar1(n, 4.0, 0.9, rng)]
            out[p] = (t[keep] // 3, xy[keep] + err, v[keep])
        return out, L.DT * 3
    if modality in ("BLE", "Truth"):
        return tr, L.DT
    raise ValueError(modality)


def ble_distance(d, rng, sigma_db=6.0, n_pl=2.0, p0=-59.0):
    """Log-distance path loss + AR(1) shadowing + body-shielding; median filtered."""
    d = np.maximum(d, 0.1)
    shadow = ar1(len(d), sigma_db, 0.8, rng)
    body = np.where(rng.random() < 0.5, -5.0, 0.0)     # per-pair orientation/body loss
    rssi = p0 - 10 * n_pl * np.log10(d) + shadow + body
    dhat = 10 ** ((p0 - rssi) / (10 * n_pl))
    if len(dhat) >= 5:
        dhat = pd.Series(dhat).rolling(5, center=True, min_periods=1).median().values
    return dhat


def pair_table(scene, modality="Truth", rng=RNG):
    df, groups = L.load_scene(scene)
    g_of = L.group_lookup(groups)
    tr0 = L.tracks_from_df(df)
    tr, dt = modality_tracks(tr0, modality, rng)
    fi = L.frame_index(tr)
    nper = np.array([len(f.pid) for f in fi.values()])
    # mean nearest-neighbour distance (density descriptor)
    from scipy.spatial import cKDTree
    nn = []
    for f in fi.values():
        if len(f.pid) >= 2:
            dd, _ = cKDTree(f.xy).query(f.xy, k=2); nn.append(np.median(dd[:, 1]))
    pids = sorted(tr)
    rows = []
    for a, b in combinations(pids, 2):
        ps = L.pair_series(tr, a, b)
        same = int(a in g_of and b in g_of and g_of[a] == g_of[b])
        if ps is None or len(ps[0]) < 2:
            if same:
                rows.append((a, b, same, np.zeros(len(DS_GRID))))
            continue
        d = np.linalg.norm(ps[1] - ps[2], axis=1)
        if modality == "BLE":
            d = ble_distance(d, rng)
        if d.min() > DS_GRID[-1]:
            if same:
                rows.append((a, b, same, np.zeros(len(DS_GRID))))
            continue
        mr = np.array([maxrun_seconds(d, ds, dt) for ds in DS_GRID])
        rows.append((a, b, same, mr))
    y = np.array([r[2] for r in rows]); M = np.vstack([r[3] for r in rows])
    n_pos_total = sum(1 for g in groups for _ in combinations(g, 2))
    meta = dict(scene=scene, modality=modality, persons=len(tr0), mean_per_frame=float(nper.mean()),
                median_nn=float(np.median(nn)), n_pairs_eval=len(y), n_pos=int(y.sum()),
                n_pos_annot=n_pos_total)
    return y, M, meta


def f1_grid(y, M):
    """F1 for every (d_s, t_min) cell."""
    P = M[:, :, None] >= T_GRID[None, None, :]          # pairs x ds x t
    tp = (P & (y[:, None, None] == 1)).sum(0)
    fp = (P & (y[:, None, None] == 0)).sum(0)
    fn = y.sum() - tp
    prec = tp / np.maximum(tp + fp, 1); rec = tp / np.maximum(tp + fn, 1)
    f1 = 2 * prec * rec / np.maximum(prec + rec, 1e-9)
    return f1, prec, rec


def f1_at(y, M, ds, t):
    i = int(np.argmin(np.abs(DS_GRID - ds)))
    p = M[:, i] >= t
    tp = (p & (y == 1)).sum(); fp = (p & (y == 0)).sum(); fn = y.sum() - tp
    pr = tp / max(tp + fp, 1); rc = tp / max(tp + fn, 1)
    return 2 * pr * rc / max(pr + rc, 1e-9), pr, rc


def boot_f1(y, M, ds, t, B=1000, rng=np.random.default_rng(7)):
    i = int(np.argmin(np.abs(DS_GRID - ds))); p = M[:, i] >= t
    n = len(y); out = []
    for _ in range(B):
        k = rng.integers(0, n, n); yy = y[k]; pp = p[k]
        tp = (pp & (yy == 1)).sum(); fp = (pp & (yy == 0)).sum(); fn = yy.sum() - tp
        pr = tp / max(tp + fp, 1); rc = tp / max(tp + fn, 1)
        out.append(2 * pr * rc / max(pr + rc, 1e-9))
    return np.percentile(out, [2.5, 97.5])


if __name__ == "__main__":
    res = {}; metas = []
    for mod in ["Truth", "Camera", "BLE", "GPS"]:
        for s in L.SCENES:
            y, M, meta = pair_table(s, mod)
            res[(mod, s)] = (y, M); metas.append(meta)
            print(meta, flush=True)
    np.save("../results/exp1_tables.npy", {f"{k[0]}|{k[1]}": v for k, v in res.items()}, allow_pickle=True)
    pd.DataFrame(metas).to_csv("../results/exp1_meta.csv", index=False)

    rows = []
    for mod in ["Truth", "Camera", "BLE", "GPS"]:
        grids = {s: f1_grid(*res[(mod, s)])[0] for s in L.SCENES}
        for s in L.SCENES:
            y, M = res[(mod, s)]
            g = grids[s]
            i, j = np.unravel_index(np.argmax(g), g.shape)
            # LOSO: thresholds maximising mean F1 over the other four scenes
            other = np.mean([grids[o] for o in L.SCENES if o != s], axis=0)
            li, lj = np.unravel_index(np.argmax(other), other.shape)
            f_loso, p_loso, r_loso = f1_at(y, M, DS_GRID[li], T_GRID[lj])
            ci = boot_f1(y, M, DS_GRID[li], T_GRID[lj])
            f_def60 = f1_at(y, M, 1.5, 60)[0]
            f_def15 = f1_at(y, M, 1.5, 15)[0]
            rows.append(dict(modality=mod, scene=s, oracle_ds=DS_GRID[i], oracle_t=T_GRID[j],
                             oracle_f1=g[i, j], loso_ds=DS_GRID[li], loso_t=T_GRID[lj],
                             loso_f1=f_loso, loso_prec=p_loso, loso_rec=r_loso,
                             loso_ci_lo=ci[0], loso_ci_hi=ci[1],
                             default_1p5m_60s=f_def60, default_1p5m_15s=f_def15))
    out = pd.DataFrame(rows)
    out.to_csv("../results/exp1_thresholds.csv", index=False)
    pd.set_option("display.width", 250)
    print(out.round(3))
