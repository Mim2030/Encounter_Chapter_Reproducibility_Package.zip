"""Figures 6-8 from experiment outputs."""
import numpy as np, pandas as pd
import matplotlib.pyplot as plt
from figs_common import *

R = "/home/claude/work/results"
# ---------------- Figure 6: label budget
B = pd.concat([pd.read_csv(f"{R}/exp3_budget.csv"), pd.read_csv(f"{R}/exp3c_rule_budget.csv")])
fig, ax = plt.subplots(1, 2, figsize=(6.6, 2.8))
style = {"Rule-based": (INK2, "o", "-"), "Supervised RF": (S1, "s", "-"), "Hybrid": (S2, "D", "--"),
         "Unsupervised GMM": (S3, "^", ":")}
for k, met in enumerate(["macroF1", "socialF1"]):
    a = ax[k]
    for m, (c, mk, ls) in style.items():
        g = B[B.method == m].groupby("frac")[met].agg(["mean", "std"]).reset_index().fillna(0)
        a.plot(g.frac * 100, g["mean"], color=c, marker=mk, ms=4.5, ls=ls, lw=1.8, label=m)
        a.fill_between(g.frac * 100, g["mean"] - g["std"], g["mean"] + g["std"], color=c, alpha=0.12, lw=0)
    a.set_xscale("log"); a.set_xticks([1, 2, 5, 10, 25, 50, 100]); a.set_xticklabels(["1", "2", "5", "10", "25", "50", "100"])
    a.set_xlabel("Labelled share of training episodes (%)")
    a.set_ylabel("LOSO macro-F1" if k == 0 else "LOSO social F1"); a.set_ylim(0.2, 0.9)
    a.set_title("(a) Four-class macro-F1" if k == 0 else "(b) Social vs transit F1", loc="left")
ax[0].legend(loc="upper center", bbox_to_anchor=(1.1, -0.25), ncol=4, fontsize=7.5)
save(fig, "fig6_label_budget")

# ---------------- Figure 7: sensitivity
S = pd.read_csv(f"{R}/exp4_sensitivity.csv")
base = S[S.factor == "baseline"].iloc[0]
panels = [("position noise (m)", "(a) Positional error σ (m)", 0.0, "log"),
          ("sampling interval (s)", "(b) Sampling interval (s)", 0.4, "log"),
          ("occlusion hazard (/frame)", "(c) Occlusion hazard per frame", 0.0, "linear"),
          ("field of view (fraction)", "(d) Field of view (share of extent)", 1.0, "linear")]
fig, axs = plt.subplots(2, 2, figsize=(6.4, 4.6), sharey=True)
fig.subplots_adjust(hspace=0.5, wspace=0.12)
for a, (f, title, x0, sc) in zip(axs.flat, panels):
    g = S[S.factor == f].sort_values("level", ascending=(f != "field of view (fraction)"))
    xs = np.r_[x0, g.level.values] if f != "position noise (m)" else np.r_[0.05, g.level.values]
    for met, c, mk, ls, lab in [("rule_socialF1", S1, "o", "-", "Rule-based, social F1"),
                                ("rule_macroF1", S1, "o", "--", "Rule-based, macro-F1"),
                                ("socialF1", S2, "s", "-", "Random forest, social F1"),
                                ("macroF1", S2, "s", "--", "Random forest, macro-F1")]:
        a.plot(xs, np.r_[base[met], g[met].values], color=c, marker=mk, ms=3.5, lw=1.6, ls=ls, label=lab)
    a.set_xscale(sc); a.minorticks_off(); a.set_title(title, loc="left", fontsize=8.5); a.set_ylim(0, 0.9)
    if f == "position noise (m)":
        a.set_xticks([0.05, 0.25, 1, 4]); a.set_xticklabels(["0", "0.25", "1", "4"])
    if f == "sampling interval (s)":
        a.set_xticks([0.4, 1, 2, 4]); a.set_xticklabels(["0.4", "1", "2", "4"])
    if f == "field of view (fraction)":
        a.invert_xaxis()
axs[0, 0].set_ylabel("LOSO score"); axs[1, 0].set_ylabel("LOSO score")
axs[1, 0].legend(loc="upper center", bbox_to_anchor=(1.05, -0.2), ncol=2, fontsize=7.5)
save(fig, "fig7_sensitivity")

# ---------------- Figure 8: scalability
P = pd.read_csv(f"{R}/exp6_pairsearch.csv"); MEM = pd.read_csv(f"{R}/exp6_memory_rss.csv")
fig, ax = plt.subplots(1, 2, figsize=(6.6, 2.8))
for m, c, mk in [("Brute force", S2, "s"), ("k-d tree", S1, "o"), ("Grid hash", S3, "^")]:
    g = P[P.method == m]
    ax[0].plot(g.N, g.seconds, color=c, marker=mk, ms=4.5, lw=1.8, label=m)
    gm = MEM[MEM.method == m]
    ax[1].plot(gm.N, gm.peak_rss_increase_MB, color=c, marker=mk, ms=4.5, lw=1.8, label=m)
for a in ax:
    a.set_xscale("log"); a.set_yscale("log"); a.set_xlabel("Tracked entities per frame, N")
ax[0].set_ylabel("Seconds per frame"); ax[1].set_ylabel("Peak memory increase (MB)")
ax[0].set_title("(a) Candidate-pair search time", loc="left"); ax[1].set_title("(b) Peak resident memory", loc="left")
ax[0].legend(fontsize=7.5, loc="upper left")
save(fig, "fig8_scalability")
print("ok")
