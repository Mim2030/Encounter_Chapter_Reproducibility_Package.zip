"""Assemble chapter markdown -> .docx (pandoc, native Word equations) using the original
manuscript as reference document, then restore the original manuscript formatting."""
import subprocess, re, sys
from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

W = "/home/claude/work"
parts = [f"{W}/chapter/part{i}.md" for i in (1, 2, 3, 4)]
md = "\n\n".join(open(p).read() for p in parts)
open(f"{W}/chapter/chapter.md", "w").write(md)
out = sys.argv[1] if len(sys.argv) > 1 else f"{W}/out/Encounter_Classification_revised.docx"
subprocess.run(["pandoc", f"{W}/chapter/chapter.md", "-f", "markdown+tex_math_dollars+pipe_tables",
                "-o", out, "--reference-doc=/home/claude/src/original.docx", "--resource-path", W],
               check=True)

d = Document(out)
body_styles = {"Body Text", "First Paragraph", "Compact", "Normal"}


def set_body(p, after=160, line=360, justify=True):
    pf = p.paragraph_format
    pf.space_after = Pt(after / 20); pf.space_before = Pt(0)
    pf.line_spacing = line / 240
    if justify:
        p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY


normal = d.styles["Normal"]
for p in d.paragraphs:
    sn = p.style.name
    txt = p.text.strip()
    if sn in ("Heading 1", "Heading 2", "Heading 3"):
        continue
    if sn in body_styles or sn.startswith("Body"):
        p.style = normal
        if txt.startswith("Figure ") and p.runs and p.runs[0].italic:
            set_body(p, after=240, line=276, justify=False)
            p.alignment = WD_ALIGN_PARAGRAPH.LEFT
        elif re.match(r"^Table \d+$", txt):
            set_body(p, after=60, line=276, justify=False)
            p.paragraph_format.keep_with_next = True
        elif p.runs and all(r.italic for r in p.runs if r.text.strip()) and txt and len(txt) < 200 and \
                p._p.getprevious() is not None and re.match(r"^Table \d+$", "".join(
                    t.text or "" for t in p._p.getprevious().iter(qn("w:t")))):
            set_body(p, after=120, line=276, justify=False)
            p.paragraph_format.keep_with_next = True
        elif p._p.find(".//" + qn("w:drawing")) is not None:
            set_body(p, after=60, line=240, justify=False)
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.keep_with_next = True
        else:
            set_body(p)
    # references / additional reading: hanging indent
for i, p in enumerate(d.paragraphs):
    pass

in_refs = False
for p in d.paragraphs:
    if p.style.name == "Heading 1":
        in_refs = p.text.strip() in ("References", "Additional Reading")
        continue
    if in_refs and p.text.strip():
        p.paragraph_format.left_indent = Inches(0.5)
        p.paragraph_format.first_line_indent = Inches(-0.5)
        p.alignment = WD_ALIGN_PARAGRAPH.LEFT
        p.paragraph_format.line_spacing = 1.15
        p.paragraph_format.space_after = Pt(6)


def border(el, tag, color="888888"):
    b = OxmlElement(f"w:{tag}")
    for k, v in (("val", "single"), ("sz", "4"), ("space", "0"), ("color", color)):
        b.set(qn(f"w:{k}"), v)
    el.append(b)


for t in d.tables:
    tblPr = t._tbl.tblPr
    for old in tblPr.findall(qn("w:tblBorders")):
        tblPr.remove(old)
    bd = OxmlElement("w:tblBorders")
    for tag in ("top", "left", "bottom", "right", "insideH", "insideV"):
        border(bd, tag)
    tblPr.append(bd)
    for old in tblPr.findall(qn("w:tblW")):
        tblPr.remove(old)
    tw = OxmlElement("w:tblW"); tw.set(qn("w:w"), "5000"); tw.set(qn("w:type"), "pct"); tblPr.append(tw)
    mar = OxmlElement("w:tblCellMar")
    for side, v in (("top", "50"), ("left", "90"), ("bottom", "50"), ("right", "90")):
        e = OxmlElement(f"w:{side}"); e.set(qn("w:w"), v); e.set(qn("w:type"), "dxa"); mar.append(e)
    tblPr.append(mar)
    for ri, row in enumerate(t.rows):
        for cell in row.cells:
            if ri == 0:
                tcPr = cell._tc.get_or_add_tcPr()
                shd = OxmlElement("w:shd"); shd.set(qn("w:val"), "clear"); shd.set(qn("w:color"), "auto")
                shd.set(qn("w:fill"), "D9E2F3"); tcPr.append(shd)
            for p in cell.paragraphs:
                p.style = normal
                p.paragraph_format.space_after = Pt(0); p.paragraph_format.line_spacing = 1.0
                p.alignment = WD_ALIGN_PARAGRAPH.LEFT
                for r in p.runs:
                    r.font.size = Pt(9.5)
                    if ri == 0:
                        r.bold = True
for t in d.tables:
    nxt = t._tbl.getnext()
    if nxt is not None and nxt.tag == qn("w:p"):
        from docx.text.paragraph import Paragraph
        Paragraph(nxt, d._body).paragraph_format.space_before = Pt(10)
d.save(out)
print("saved", out)
