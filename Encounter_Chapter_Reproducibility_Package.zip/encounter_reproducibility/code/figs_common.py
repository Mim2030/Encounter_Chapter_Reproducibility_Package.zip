import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# Reference palette (dataviz skill), light mode; fixed slot order
S1, S2, S3, S4 = "#2a78d6", "#eb6834", "#1baf7a", "#eda100"
GRAY = "#8a8985"; INK = "#0b0b0b"; INK2 = "#52514e"; GRID = "#e4e3df"
SEQ = ["#cde2fb", "#9ec5f4", "#6da7ec", "#3987e5", "#256abf", "#184f95", "#0d366b"]
CLASS_COL = {"Transit": GRAY, "Companionate": S1, "Dyadic": S2, "Group": S3}
CLASS_LAB = {"Transit": "Transit Crossing", "Companionate": "Companionate Movement",
             "Dyadic": "Stationary dyad", "Group": "Group Encounter"}
FIG = "/home/claude/work/figs"

plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 8.5, "axes.titlesize": 9, "axes.labelsize": 8.5,
    "axes.edgecolor": INK2, "axes.labelcolor": INK, "xtick.color": INK2, "ytick.color": INK2,
    "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True, "grid.color": GRID,
    "grid.linewidth": 0.6, "axes.axisbelow": True, "legend.frameon": False, "lines.linewidth": 2,
    "savefig.dpi": 300, "savefig.bbox": "tight", "figure.facecolor": "white",
})


def save(fig, name):
    fig.savefig(f"{FIG}/{name}.png")
    plt.close(fig)
