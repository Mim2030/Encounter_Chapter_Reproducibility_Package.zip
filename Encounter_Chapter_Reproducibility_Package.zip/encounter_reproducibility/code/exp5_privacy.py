"""Experiment 5: privacy-preserving mechanisms.
(a) Differentially private release of encounter hotspot maps (Laplace mechanism with
    per-person contribution bounding): utility vs epsilon, overhead.
(b) Federated learning (FedAvg) across scenes-as-sites vs centralised and local-only
    training, with and without DP-SGD (per-example clipping + Gaussian noise, RDP
    accountant): macro-F1, communication cost, compute time, (epsilon, delta)."""
import numpy as np, pandas as pd, time, json, warnings
from scipy.stats import spearmanr
import dp_accounting
import encounter_lib as L
from exp2_classification import macro, binf1

warnings.filterwarnings("ignore")
E = pd.read_csv("../results/episodes_clean.csv")
E["y"] = E.ref.map({c: i for i, c in enumerate(L.CLASSES)})
FEATS = L.ALL_FEATURES
SCN = list(L.SCENES)

# ------------------------------------------------------------- (a) DP hotspots
def hotspot_dp(K=10, cell=2.0, eps_grid=(0.1, 0.25, 0.5, 1, 2, 5, 10), reps=200, seed=0):
    rng = np.random.default_rng(seed)
    rows = []
    for s in SCN:
        Es = E[E.scene == s].sample(frac=1, random_state=seed)        # random order for bounding
        # contribution bounding: each person may appear in at most K released episodes
        cnt = {}; keep = []
        for a, b in zip(Es.a, Es.b):
            ok = cnt.get(a, 0) < K and cnt.get(b, 0) < K
            keep.append(ok)
            if ok:
                cnt[a] = cnt.get(a, 0) + 1; cnt[b] = cnt.get(b, 0) + 1
        Eb = Es[np.array(keep)]
        x0, y0 = E[E.scene == s].cx.min(), E[E.scene == s].cy.min()
        def grid(D):
            ix = ((D.cx - x0) // cell).astype(int); iy = ((D.cy - y0) // cell).astype(int)
            return pd.Series(1, index=pd.MultiIndex.from_arrays([ix, iy])).groupby(level=[0, 1]).sum()
        G_true = grid(Es); G_b = grid(Eb).reindex(G_true.index, fill_value=0)
        # cells: full bounding box
        allc = pd.MultiIndex.from_product([range(G_true.index.levels[0].max() + 1),
                                           range(G_true.index.levels[1].max() + 1)])
        T = G_true.reindex(allc, fill_value=0).values.astype(float)
        B = G_b.reindex(allc, fill_value=0).values.astype(float)
        top_true = set(np.argsort(-T)[:10])
        # sensitivity: removing one person removes <= K episodes, each in one cell -> L1 = K
        for eps in eps_grid:
            rec, rho, mae, tms = [], [], [], []
            for _ in range(reps):
                t1 = time.perf_counter()
                N = B + rng.laplace(0, K / eps, B.shape)
                tms.append(time.perf_counter() - t1)
                rec.append(len(top_true & set(np.argsort(-N)[:10])) / 10)
                rho.append(spearmanr(T, N).statistic)
                mae.append(np.abs(N - T).mean())
            rows.append(dict(scene=s, eps=eps, K=K, cells=len(T), episodes=len(Es),
                             kept_after_bounding=len(Eb) / len(Es), top10_recall=np.mean(rec),
                             spearman=np.mean(rho), mae=np.mean(mae), noise_ms=1000 * np.mean(tms)))
        rows.append(dict(scene=s, eps=np.inf, K=K, cells=len(T), episodes=len(Es),
                         kept_after_bounding=len(Eb) / len(Es),
                         top10_recall=len(top_true & set(np.argsort(-B)[:10])) / 10,
                         spearman=spearmanr(T, B).statistic, mae=np.abs(B - T).mean(), noise_ms=0))
    return pd.DataFrame(rows)


# ------------------------------------------------------------- (b) FL with numpy MLP
H = 32


def init(d, rng):
    return [rng.normal(0, np.sqrt(2 / d), (d, H)), np.zeros(H), rng.normal(0, np.sqrt(2 / H), (H, 4)), np.zeros(4)]


def forward(w, X):
    z1 = X @ w[0] + w[1]; h = np.maximum(z1, 0); z2 = h @ w[2] + w[3]
    z2 -= z2.max(1, keepdims=True); p = np.exp(z2); p /= p.sum(1, keepdims=True)
    return z1, h, p


def grads(w, X, y, cw, clip=None, noise=0.0, rng=None):
    z1, h, p = forward(w, X)
    Y = np.eye(4)[y]
    d2 = (p - Y) * cw[y][:, None]
    d1 = (d2 @ w[2].T) * (z1 > 0)
    if clip is not None:   # per-example clipping (norm of outer products = product of norms)
        nrm = np.sqrt((h ** 2).sum(1) * (d2 ** 2).sum(1) + (d2 ** 2).sum(1)
                      + (X ** 2).sum(1) * (d1 ** 2).sum(1) + (d1 ** 2).sum(1))
        c = np.minimum(1, clip / (nrm + 1e-12))
        d2 = d2 * c[:, None]; d1 = d1 * c[:, None]
    g = [X.T @ d1, d1.sum(0), h.T @ d2, d2.sum(0)]
    if clip is not None and noise > 0:
        g = [gi + rng.normal(0, noise * clip, gi.shape) for gi in g]
    return g


def local_train(w, X, y, cw, epochs, lr, rng, batch=64, clip=None, noise=0.0):
    w = [wi.copy() for wi in w]; mom = [np.zeros_like(wi) for wi in w]
    n = len(X); q = batch / n; steps = 0
    for _ in range(epochs):
        for _ in range(max(1, n // batch)):
            if clip is not None:          # Poisson subsampling for DP accounting
                idx = np.flatnonzero(rng.random(n) < q)
                if len(idx) == 0:
                    continue
                g = grads(w, X[idx], y[idx], cw, clip, noise, rng); denom = batch
            else:
                idx = rng.integers(0, n, batch)
                g = grads(w, X[idx], y[idx], cw); denom = batch
            for k in range(4):
                mom[k] = 0.9 * mom[k] + g[k] / denom
                w[k] -= lr * mom[k]
            steps += 1
    return w, steps


def predict(w, X):
    return forward(w, X)[2].argmax(1)


def fed_stats(clients):
    """Federated standardisation and class weights from per-client sufficient statistics."""
    n = sum(len(c[0]) for c in clients)
    mu = sum(c[0].sum(0) for c in clients) / n
    var = sum(((c[0] - mu) ** 2).sum(0) for c in clients) / n
    counts = sum(np.bincount(c[1], minlength=4) for c in clients)
    cw = n / (4 * np.maximum(counts, 1))
    return mu, np.sqrt(var) + 1e-9, cw


def epsilon(steps, q, noise, delta=1e-5):
    acc = dp_accounting.rdp.RdpAccountant()
    ev = dp_accounting.PoissonSampledDpEvent(q, dp_accounting.GaussianDpEvent(noise))
    acc.compose(ev, steps)
    return acc.get_epsilon(delta)


def run_fl(rounds=40, local_epochs=1, lr=0.02, seed=0, clip=None, noise=0.0):
    p_fed = np.zeros(len(E), int); p_cen = np.zeros(len(E), int); p_loc = np.zeros(len(E), int)
    comm = 0; t_fed = 0; t_cen = 0; eps_list = []
    nparams = None
    for s in SCN:
        rng = np.random.default_rng(seed)
        train_scenes = [o for o in SCN if o != s]
        clients = [(E.loc[E.scene == o, FEATS].values, E.loc[E.scene == o, "y"].values) for o in train_scenes]
        mu, sd, cw = fed_stats(clients)
        clients = [((X - mu) / sd, y) for X, y in clients]
        Xte = (E.loc[E.scene == s, FEATS].values - mu) / sd; te = (E.scene == s).values
        w = init(len(FEATS), rng); nparams = sum(wi.size for wi in w)
        t1 = time.perf_counter(); steps_max = {}
        for r in range(rounds):
            new = []; ns = []
            for ci, (X, y) in enumerate(clients):
                wl, st = local_train(w, X, y, cw, local_epochs, lr, rng, clip=clip, noise=noise)
                new.append(wl); ns.append(len(X)); steps_max[ci] = steps_max.get(ci, 0) + st
            tot = sum(ns)
            w = [sum(nw[k] * n_ / tot for nw, n_ in zip(new, ns)) for k in range(4)]
            comm += 2 * len(clients) * nparams * 4          # float32 down + up
        t_fed += time.perf_counter() - t1
        p_fed[te] = predict(w, Xte)
        if clip is not None:
            for ci, (X, _) in enumerate(clients):
                eps_list.append(epsilon(steps_max[ci], 64 / len(X), noise))
        if clip is None:
            # centralised: pooled data, same number of passes
            Xp = np.vstack([c[0] for c in clients]); yp = np.concatenate([c[1] for c in clients])
            t1 = time.perf_counter()
            wc, _ = local_train(init(len(FEATS), np.random.default_rng(seed)), Xp, yp, cw,
                                rounds * local_epochs, lr, np.random.default_rng(seed))
            t_cen += time.perf_counter() - t1
            p_cen[te] = predict(wc, Xte)
            # local-only: each site's own model, scored on held-out scene; report mean
            loc_preds = []
            for X, y in clients:
                cw_l = len(y) / (4 * np.maximum(np.bincount(y, minlength=4), 1))
                wl, _ = local_train(init(len(FEATS), np.random.default_rng(seed)), X, y, cw_l,
                                    rounds * local_epochs, lr, np.random.default_rng(seed))
                loc_preds.append(predict(wl, Xte))
            p_loc[te] = loc_preds[0]
            E.loc[te, "loc_f1s"] = np.nan
            for k, lp in enumerate(loc_preds):
                E.loc[te, f"loc{k}"] = lp
    y = E.y.values
    res = dict(rounds=rounds, clip=clip, noise=noise, fed_macroF1=macro(y, p_fed), fed_socialF1=binf1(y, p_fed),
               comm_MB=comm / 1e6, fed_time_s=t_fed, params=nparams,
               eps_max=max(eps_list) if eps_list else np.inf, eps_median=np.median(eps_list) if eps_list else np.inf)
    if clip is None:
        loc_scores = [macro(y, E[f"loc{k}"].values.astype(int)) for k in range(4)]
        res.update(cen_macroF1=macro(y, p_cen), cen_socialF1=binf1(y, p_cen), cen_time_s=t_cen,
                   local_macroF1_mean=float(np.mean(loc_scores)), local_macroF1_min=float(np.min(loc_scores)),
                   local_macroF1_max=float(np.max(loc_scores)))
    return res


if __name__ == "__main__":
    t0 = time.time()
    hs = hotspot_dp(); hs.to_csv("../results/exp5_dp_hotspots.csv", index=False)
    print(hs.groupby("eps")[["top10_recall", "spearman", "kept_after_bounding", "noise_ms"]].mean().round(3), flush=True)
    raw_feature_bytes = len(E) * len(FEATS) * 4
    raw_traj_bytes = sum(len(L.load_scene(s)[0]) for s in SCN) * 3 * 4
    fl = []
    for seed in range(3):
        r = run_fl(seed=seed); r["seed"] = seed; fl.append(r); print(r, round(time.time() - t0), flush=True)
        for nm in [0.5, 1.0, 2.0]:
            r = run_fl(seed=seed, clip=1.0, noise=nm); r["seed"] = seed; fl.append(r)
            print(r, round(time.time() - t0), flush=True)
    F = pd.DataFrame(fl); F["raw_feature_upload_MB"] = raw_feature_bytes / 1e6; F["raw_traj_upload_MB"] = raw_traj_bytes / 1e6
    F.to_csv("../results/exp5_federated.csv", index=False)
    print("done", round(time.time() - t0))
