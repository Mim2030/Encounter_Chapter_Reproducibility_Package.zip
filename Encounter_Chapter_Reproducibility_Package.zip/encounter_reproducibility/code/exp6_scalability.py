"""Experiment 6: scalability benchmarks.
(a) per-frame candidate-pair search: brute force O(N^2) vs k-d tree vs uniform grid
    hashing, for N = 10^2 ... 10^6 entities at fixed density; runtime and peak memory.
(b) end-to-end pipeline (episode extraction + feature computation + RF inference)
    on C replicated camera streams (C = 1..8) to test linear scaling across cameras.
(c) encounter-event volume as a function of crowd density."""
import numpy as np, pandas as pd, time, tracemalloc, gc
from scipy.spatial import cKDTree
import encounter_lib as L
from exp2_classification import rf

RNG = np.random.default_rng(0)
R = 2.0          # pedestrian-scale radius (m)
DENS = 0.2       # persons per m^2 (busy plaza)


def brute(P, r):
    n = len(P); cnt = 0; B = 500
    for i in range(0, n, B):
        d2 = ((P[i:i + B, None, :] - P[None, :, :]) ** 2).sum(-1)
        cnt += int((d2 <= r * r).sum())
    return (cnt - n) // 2


def kdtree(P, r):
    return len(cKDTree(P).query_pairs(r, output_type="ndarray"))


def grid_hash(P, r):
    """Uniform grid with cell = r; compare each cell with itself and 4 forward neighbours."""
    c = np.floor(P / r).astype(np.int64)
    key = c[:, 0] * 1_000_003 + c[:, 1]
    order = np.argsort(key); key_s = key[order]; Ps = P[order]
    uk, start, cnts = np.unique(key_s, return_index=True, return_counts=True)
    lut = dict(zip(uk.tolist(), zip(start.tolist(), cnts.tolist())))
    total = 0
    for k, (s0, n0) in lut.items():
        A = Ps[s0:s0 + n0]
        d2 = ((A[:, None] - A[None]) ** 2).sum(-1)
        total += (int((d2 <= r * r).sum()) - n0) // 2
        for off in (1_000_003, 1_000_003 + 1, 1, -1_000_003 + 1):
            if k + off in lut:
                s1, n1 = lut[k + off]; Bq = Ps[s1:s1 + n1]
                total += int((((A[:, None] - Bq[None]) ** 2).sum(-1) <= r * r).sum())
    return total


def bench(fn, P, reps=3):
    gc.collect(); tracemalloc.start()
    t = []; out = None
    for _ in range(reps):
        t1 = time.perf_counter(); out = fn(P, R); t.append(time.perf_counter() - t1)
    peak = tracemalloc.get_traced_memory()[1]; tracemalloc.stop()
    return np.median(t), peak / 1e6, out


if __name__ == "__main__":
    rows = []
    for N in [100, 300, 1000, 3000, 10000, 30000, 100000, 300000, 1000000]:
        side = np.sqrt(N / DENS); P = RNG.random((N, 2)) * side
        for name, fn, nmax in [("Brute force", brute, 30000), ("k-d tree", kdtree, 10 ** 7),
                               ("Grid hash", grid_hash, 300000)]:
            if N > nmax:
                continue
            t, mem, k = bench(fn, P, reps=3 if N <= 100000 else 1)
            rows.append(dict(N=N, method=name, seconds=t, peak_MB=mem, pairs=k))
            print(rows[-1], flush=True)
    A = pd.DataFrame(rows); A.to_csv("../results/exp6_pairsearch.csv", index=False)
    # empirical scaling exponents (log-log slope over N >= 1000)
    for m, g in A[A.N >= 1000].groupby("method"):
        print(m, "slope", np.polyfit(np.log(g.N), np.log(g.seconds), 1)[0].round(2))

    # (b) end-to-end on replicated camera streams
    E = pd.read_csv("../results/episodes_clean.csv")
    model = rf(0, n_estimators=300).fit(E[L.ALL_FEATURES].values, E.ref.values)
    df, groups = L.load_scene("Students")
    e2e = []
    for C in [1, 2, 4, 8]:
        t1 = time.perf_counter(); n_ep = 0
        tracemalloc.start()
        for c in range(C):
            tr = L.tracks_from_df(df)
            ep = L.extract_episodes(tr, groups, f"cam{c}")
            model.predict(ep[L.ALL_FEATURES].values); n_ep += len(ep)
        peak = tracemalloc.get_traced_memory()[1] / 1e6; tracemalloc.stop()
        el = time.perf_counter() - t1
        frames = C * df.t.nunique(); person_frames = C * len(df)
        e2e.append(dict(cameras=C, seconds=el, episodes=n_ep, frames=frames, person_frames=person_frames,
                        frames_per_s=frames / el, realtime_factor=(frames * L.DT) / el, peak_MB=peak))
        print(e2e[-1], flush=True)
    pd.DataFrame(e2e).to_csv("../results/exp6_end2end.csv", index=False)

    # inference throughput
    X = E[L.ALL_FEATURES].values
    t1 = time.perf_counter(); model.predict(np.tile(X, (10, 1))); t_inf = time.perf_counter() - t1
    # (c) pair volume vs density
    vol = []
    for dens in [0.01, 0.05, 0.1, 0.2, 0.5, 1.0]:
        N = 10000; side = np.sqrt(N / dens); P = RNG.random((N, 2)) * side
        k = kdtree(P, R)
        vol.append(dict(density=dens, pairs_per_person=2 * k / N, expected=dens * np.pi * R * R))
    pd.DataFrame(vol).to_csv("../results/exp6_volume.csv", index=False)
    print(pd.DataFrame(vol), "\ninference episodes/s", round(10 * len(X) / t_inf))
    with open("../results/exp6_inference.txt", "w") as fh:
        fh.write(f"rf_inference_episodes_per_s={10 * len(X) / t_inf:.0f}\n")
